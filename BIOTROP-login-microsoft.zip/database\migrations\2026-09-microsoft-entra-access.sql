-- BIOTROP — Login Microsoft (Entra ID) restrito ao domínio corporativo + gestão de usuários
-- Migração idempotente. Não remove dados existentes.
-- Depende de: database/BIOTROP_INSTALACAO_V2.sql e database/migrations/2026-09-corporate-access.sql

begin;

create extension if not exists pgcrypto;

-- ============================================================================
-- 1. CONFIGURAÇÃO CORPORATIVA DE ACESSO (singleton)
-- ============================================================================

create table if not exists public.corporate_access_settings (
  id boolean primary key default true,
  entra_tenant_id text,
  password_login_mode text not null default 'exceptions',
  auto_provision boolean not null default true,
  auto_activate boolean not null default true,
  default_role_code text not null default 'viewer',
  updated_at timestamptz not null default now(),
  updated_by uuid references auth.users(id) on delete set null,
  constraint corporate_access_settings_singleton check (id),
  constraint corporate_access_settings_password_mode
    check (password_login_mode in ('disabled', 'exceptions', 'open'))
);

comment on column public.corporate_access_settings.password_login_mode is
  'disabled = somente Microsoft; exceptions = senha apenas para e-mails na allowlist; open = senha liberada para todos.';
comment on column public.corporate_access_settings.auto_activate is
  'true = colaborador Biotrop entra já ativo com o perfil padrão; false = fica aguardando liberação do administrador.';

insert into public.corporate_access_settings(id) values (true) on conflict (id) do nothing;

-- ============================================================================
-- 2. DOMÍNIOS AUTORIZADOS
-- ============================================================================

create table if not exists public.corporate_allowed_domains (
  domain text primary key,
  description text,
  enabled boolean not null default true,
  created_at timestamptz not null default now()
);

insert into public.corporate_allowed_domains(domain, description, enabled)
values ('biotrop.com.br', 'Domínio corporativo Biotrop', true)
on conflict (domain) do update set enabled = true;

-- ============================================================================
-- 3. EXCEÇÕES DE LOGIN (allowlist) — amplia a tabela já existente
-- ============================================================================

create table if not exists public.corporate_access_allowlist (
  id uuid primary key default gen_random_uuid(),
  email text not null unique,
  display_name text,
  enabled boolean not null default true,
  allowed_roles text[] not null default array['viewer']::text[],
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.corporate_access_allowlist add column if not exists allow_password_login boolean not null default true;
alter table public.corporate_access_allowlist add column if not exists note text;
alter table public.corporate_access_allowlist add column if not exists expires_at timestamptz;
alter table public.corporate_access_allowlist add column if not exists created_by uuid references auth.users(id) on delete set null;

create index if not exists idx_corporate_allowlist_email_enabled
  on public.corporate_access_allowlist(lower(email)) where enabled;

-- ============================================================================
-- 4. PERFIS: CAMPOS CORPORATIVOS E DE IDENTIDADE MICROSOFT
-- ============================================================================

alter table public.profiles add column if not exists azure_oid text;
alter table public.profiles add column if not exists azure_tenant_id text;
alter table public.profiles add column if not exists auth_provider text;
alter table public.profiles add column if not exists job_title text;
alter table public.profiles add column if not exists employee_id text;
alter table public.profiles add column if not exists office_location text;
alter table public.profiles add column if not exists manager_id uuid references public.profiles(id) on delete set null;
alter table public.profiles add column if not exists manager_email text;
alter table public.profiles add column if not exists access_status text;
alter table public.profiles add column if not exists status_reason text;
alter table public.profiles add column if not exists status_changed_at timestamptz;
alter table public.profiles add column if not exists status_changed_by uuid references auth.users(id) on delete set null;
alter table public.profiles add column if not exists entra_synced_at timestamptz;

create unique index if not exists ux_profiles_azure_oid on public.profiles(azure_oid) where azure_oid is not null;
create index if not exists idx_profiles_manager on public.profiles(manager_id);
create index if not exists idx_profiles_access_status on public.profiles(access_status);
create index if not exists idx_profiles_email_lower on public.profiles(lower(email));

update public.profiles
set access_status = case
      when coalesce(active, false) and coalesce(is_active, false) then 'ativo'
      else 'inativo'
    end
where access_status is null;

alter table public.profiles alter column access_status set default 'inativo';

do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'profiles_access_status_check'
  ) then
    alter table public.profiles
      add constraint profiles_access_status_check
      check (access_status in ('ativo', 'inativo', 'bloqueado', 'afastado', 'desligado'));
  end if;
end;
$$;

-- Mantém access_status e os booleanos legados (active/is_active) sempre coerentes,
-- independentemente de qual campo a aplicação alterou.
create or replace function public.sync_profile_access_status()
returns trigger
language plpgsql
as $$
begin
  if tg_op = 'INSERT' then
    if new.access_status is null then
      new.access_status := case
        when coalesce(new.active, false) and coalesce(new.is_active, false) then 'ativo'
        else 'inativo'
      end;
    end if;
  elsif new.access_status is distinct from old.access_status then
    if new.access_status is null then
      new.access_status := old.access_status;
    end if;
    new.status_changed_at := now();
  elsif coalesce(new.active, false) is distinct from coalesce(old.active, false)
     or coalesce(new.is_active, false) is distinct from coalesce(old.is_active, false) then
    if coalesce(new.active, false) and coalesce(new.is_active, false) then
      new.access_status := 'ativo';
    elsif coalesce(old.access_status, 'ativo') = 'ativo' then
      new.access_status := 'bloqueado';
    end if;
    new.status_changed_at := now();
  end if;

  new.active := (new.access_status = 'ativo');
  new.is_active := new.active;
  return new;
end;
$$;

drop trigger if exists trg_profiles_sync_access_status on public.profiles;
create trigger trg_profiles_sync_access_status
before insert or update on public.profiles
for each row execute function public.sync_profile_access_status();

-- ============================================================================
-- 5. GRUPOS DE ACESSO (função / setor) — base das trilhas de treinamento
-- ============================================================================

create table if not exists public.access_groups (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null,
  description text,
  kind text not null default 'funcao',
  entra_group_id text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint access_groups_kind_check check (kind in ('funcao', 'setor', 'unidade', 'custom'))
);

create table if not exists public.access_group_members (
  group_id uuid not null references public.access_groups(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  assigned_by uuid references auth.users(id) on delete set null,
  assigned_at timestamptz not null default now(),
  primary key (group_id, user_id)
);

create index if not exists idx_access_group_members_user on public.access_group_members(user_id);

insert into public.access_groups(code, name, description, kind)
values
  ('tecnico_manutencao', 'Técnico de manutenção', 'Execução de manutenção corretiva e preventiva.', 'funcao'),
  ('eletricista', 'Eletricista', 'Serviços elétricos industriais.', 'funcao'),
  ('mecanico', 'Mecânico', 'Manutenção mecânica de equipamentos.', 'funcao'),
  ('soldador', 'Soldador', 'Trabalho a quente e solda.', 'funcao'),
  ('tecnico_predial', 'Técnico predial', 'Manutenção predial e utilidades.', 'funcao'),
  ('supervisor', 'Supervisor', 'Supervisão de equipes de manutenção.', 'funcao'),
  ('gestor', 'Gestor', 'Gestão de equipe, prazos e treinamentos.', 'funcao'),
  ('almoxarifado', 'Almoxarifado', 'Materiais, SCI e SCM.', 'setor'),
  ('pcm', 'PCM', 'Planejamento e controle da manutenção.', 'setor'),
  ('utilidades', 'Utilidades', 'Água, gás, energia e vapor.', 'setor')
on conflict (code) do update
set name = excluded.name,
    description = excluded.description,
    kind = excluded.kind,
    active = true,
    updated_at = now();

-- ============================================================================
-- 6. DIRETÓRIO ENTRA ID (staging da sincronização via Microsoft Graph)
-- ============================================================================

create table if not exists public.entra_directory (
  azure_oid text primary key,
  email text,
  user_principal_name text,
  display_name text,
  given_name text,
  surname text,
  job_title text,
  department text,
  office_location text,
  employee_id text,
  mobile_phone text,
  business_phone text,
  account_enabled boolean,
  manager_oid text,
  manager_email text,
  manager_name text,
  raw jsonb,
  synced_at timestamptz not null default now()
);

create unique index if not exists ux_entra_directory_email
  on public.entra_directory(lower(email)) where email is not null;
create index if not exists idx_entra_directory_department on public.entra_directory(department);

create table if not exists public.entra_sync_runs (
  id uuid primary key default gen_random_uuid(),
  started_at timestamptz not null default now(),
  finished_at timestamptz,
  status text not null default 'running',
  users_fetched integer not null default 0,
  users_upserted integer not null default 0,
  profiles_updated integer not null default 0,
  managers_linked integer not null default 0,
  error_message text,
  triggered_by uuid references auth.users(id) on delete set null,
  constraint entra_sync_runs_status_check check (status in ('running', 'success', 'error'))
);

alter table public.entra_directory enable row level security;
alter table public.entra_sync_runs enable row level security;
alter table public.access_groups enable row level security;
alter table public.access_group_members enable row level security;
alter table public.corporate_allowed_domains enable row level security;
alter table public.corporate_access_settings enable row level security;

-- ============================================================================
-- 7. POLÍTICA DE LOGIN — decidido no banco, não no navegador
-- ============================================================================

create or replace function public.is_corporate_email_allowed(p_email text)
returns boolean
language sql
stable
security definer
set search_path = pg_catalog, public
as $$
  with target as (select lower(trim(coalesce(p_email, ''))) as email)
  select exists (
      select 1
      from public.corporate_access_allowlist a, target t
      where lower(a.email) = t.email
        and a.enabled
        and (a.expires_at is null or a.expires_at > now())
    )
    or exists (
      select 1
      from public.corporate_allowed_domains d, target t
      where d.enabled
        and t.email like ('%@' || d.domain)
    );
$$;

-- Consultada pela tela de login (anon) para decidir se o formulário de senha
-- deve aparecer. Retorna apenas flags de política, nunca dados do usuário.
create or replace function public.corporate_login_policy(p_email text default null)
returns jsonb
language plpgsql
stable
security definer
set search_path = pg_catalog, public
as $$
declare
  v_settings public.corporate_access_settings;
  v_email text := lower(trim(coalesce(p_email, '')));
  v_domain_allowed boolean := false;
  v_exception public.corporate_access_allowlist;
  v_password_allowed boolean := false;
begin
  select * into v_settings from public.corporate_access_settings where id;

  if v_email = '' then
    return jsonb_build_object(
      'microsoft_enabled', true,
      'password_login_mode', coalesce(v_settings.password_login_mode, 'exceptions'),
      'primary_domain', (select d.domain from public.corporate_allowed_domains d where d.enabled order by d.created_at limit 1),
      'domain_allowed', null,
      'password_allowed', coalesce(v_settings.password_login_mode, 'exceptions') = 'open'
    );
  end if;

  select exists (
    select 1 from public.corporate_allowed_domains d
    where d.enabled and v_email like ('%@' || d.domain)
  ) into v_domain_allowed;

  select * into v_exception
  from public.corporate_access_allowlist a
  where lower(a.email) = v_email
    and a.enabled
    and (a.expires_at is null or a.expires_at > now())
  limit 1;

  v_password_allowed := case coalesce(v_settings.password_login_mode, 'exceptions')
    when 'open' then true
    when 'disabled' then false
    else coalesce(v_exception.allow_password_login, false)
  end;

  return jsonb_build_object(
    'microsoft_enabled', true,
    'password_login_mode', coalesce(v_settings.password_login_mode, 'exceptions'),
    'primary_domain', (select d.domain from public.corporate_allowed_domains d where d.enabled order by d.created_at limit 1),
    'domain_allowed', v_domain_allowed,
    'is_exception', v_exception.id is not null,
    'password_allowed', v_password_allowed,
    'access_allowed', v_domain_allowed or v_exception.id is not null
  );
end;
$$;

revoke all on function public.corporate_login_policy(text) from public;
grant execute on function public.corporate_login_policy(text) to anon, authenticated;

-- ============================================================================
-- 8. PROVISIONAMENTO AUTOMÁTICO NO PRIMEIRO LOGIN (com trava de domínio)
-- ============================================================================

create or replace function public.handle_new_auth_user_biotrop_v3()
returns trigger
language plpgsql
security definer
set search_path = pg_catalog, public
as $$
declare
  v_settings public.corporate_access_settings;
  v_email text := lower(trim(coalesce(new.email, '')));
  v_provider text := lower(coalesce(new.raw_app_meta_data ->> 'provider', 'email'));
  v_is_microsoft boolean;
  v_exception public.corporate_access_allowlist;
  v_directory public.entra_directory;
  v_role_code text;
  v_role_id uuid;
  v_name text;
  v_status text;
begin
  select * into v_settings from public.corporate_access_settings where id;
  v_is_microsoft := v_provider in ('azure', 'azuread', 'microsoft', 'entra');

  if v_email = '' then
    raise exception using
      errcode = '22023',
      message = 'Conta sem e-mail não pode acessar a plataforma BIOTROP.';
  end if;

  -- Trava de domínio: bloqueia qualquer conta fora do domínio corporativo
  -- (inclui convidados do tenant com e-mail externo).
  if not public.is_corporate_email_allowed(v_email) then
    raise exception using
      errcode = '42501',
      message = format('Acesso restrito a contas corporativas Biotrop. E-mail não autorizado: %s', v_email);
  end if;

  select * into v_exception
  from public.corporate_access_allowlist a
  where lower(a.email) = v_email
    and a.enabled
    and (a.expires_at is null or a.expires_at > now())
  limit 1;

  -- Somente Microsoft, com exceções: contas de senha novas só nascem se
  -- estiverem liberadas na allowlist (ou se o modo estiver 'open').
  if not v_is_microsoft
     and coalesce(v_settings.password_login_mode, 'exceptions') <> 'open'
     and not coalesce(v_exception.allow_password_login, false) then
    raise exception using
      errcode = '42501',
      message = 'Esta plataforma usa login Microsoft. Solicite uma exceção ao administrador para acessar com senha.';
  end if;

  select * into v_directory
  from public.entra_directory d
  where lower(d.email) = v_email
  limit 1;

  v_name := coalesce(
    nullif(new.raw_user_meta_data ->> 'full_name', ''),
    nullif(new.raw_user_meta_data ->> 'name', ''),
    nullif(v_directory.display_name, ''),
    nullif(v_exception.display_name, ''),
    nullif(split_part(v_email, '@', 1), ''),
    'Usuário'
  );

  v_role_code := coalesce(
    (select a.allowed_roles[1] from public.corporate_access_allowlist a where a.id = v_exception.id and array_length(a.allowed_roles, 1) > 0),
    nullif(v_settings.default_role_code, ''),
    'viewer'
  );
  if not exists (select 1 from public.roles where code = v_role_code and active) then
    v_role_code := 'viewer';
  end if;

  v_status := case
    when v_is_microsoft and coalesce(v_settings.auto_activate, true) then 'ativo'
    when not v_is_microsoft and v_exception.id is not null then 'ativo'
    else 'inativo'
  end;

  insert into public.profiles(
    id, name, full_name, username, email, role_code, app_role,
    access_status, status_reason, auth_provider,
    azure_oid, azure_tenant_id,
    department, sector, job_title, employee_id, office_location,
    phone, manager_email, entra_synced_at
  )
  values (
    new.id, v_name, v_name, split_part(v_email, '@', 1), new.email, v_role_code, v_role_code,
    v_status,
    case when v_status = 'ativo' then 'Provisionado automaticamente no primeiro login.'
         else 'Aguardando liberação de perfil pelo administrador.' end,
    v_provider,
    case when v_is_microsoft then coalesce(nullif(new.raw_user_meta_data ->> 'provider_id', ''), nullif(new.raw_user_meta_data ->> 'sub', ''), v_directory.azure_oid) else v_directory.azure_oid end,
    nullif(v_settings.entra_tenant_id, ''),
    nullif(v_directory.department, ''),
    nullif(v_directory.department, ''),
    nullif(v_directory.job_title, ''),
    nullif(v_directory.employee_id, ''),
    nullif(v_directory.office_location, ''),
    coalesce(nullif(v_directory.mobile_phone, ''), nullif(v_directory.business_phone, '')),
    nullif(v_directory.manager_email, ''),
    case when v_directory.azure_oid is not null then now() else null end
  )
  on conflict (id) do update
  set email = excluded.email,
      auth_provider = excluded.auth_provider,
      updated_at = now();

  select id into v_role_id from public.roles where code = v_role_code;
  if v_role_id is not null and not exists (
    select 1 from public.user_roles where user_id = new.id and active
  ) then
    insert into public.user_roles(user_id, role_id, active)
    values (new.id, v_role_id, true)
    on conflict (user_id, role_id) do update set active = true, updated_at = now();
  end if;

  -- Vincula o gestor quando o diretório já conhece o e-mail dele.
  if v_directory.manager_email is not null then
    update public.profiles p
    set manager_id = m.id
    from public.profiles m
    where p.id = new.id
      and lower(m.email) = lower(v_directory.manager_email);
  end if;

  insert into public.access_audit_log(entity_type, entity_id, action, actor_user_id, new_values)
  values ('user_access', new.id::text, 'auto_provision', null,
    jsonb_build_object('email', v_email, 'provider', v_provider, 'role_code', v_role_code, 'access_status', v_status));

  return new;
end;
$$;

drop trigger if exists on_auth_user_created_biotrop on auth.users;
drop trigger if exists on_auth_user_created_biotrop_v2 on auth.users;
drop trigger if exists on_auth_user_created_biotrop_v3 on auth.users;
create trigger on_auth_user_created_biotrop_v3
after insert on auth.users
for each row execute function public.handle_new_auth_user_biotrop_v3();

-- ============================================================================
-- 9. GUARDA DE SESSÃO — validada a cada entrada no sistema
-- ============================================================================

create or replace function public.guard_corporate_session()
returns jsonb
language plpgsql
security definer
set search_path = pg_catalog, public, auth
as $$
declare
  v_user auth.users;
  v_settings public.corporate_access_settings;
  v_profile public.profiles;
  v_email text;
  v_provider text;
  v_is_microsoft boolean;
  v_exception public.corporate_access_allowlist;
  v_claim_name text;
  v_claim_oid text;
begin
  if auth.uid() is null then
    return jsonb_build_object('allowed', false, 'reason', 'no_session', 'message', 'Sessão ausente.');
  end if;

  select * into v_user from auth.users where id = auth.uid();
  select * into v_settings from public.corporate_access_settings where id;
  v_email := lower(trim(coalesce(v_user.email, '')));
  v_provider := lower(coalesce(v_user.raw_app_meta_data ->> 'provider', 'email'));
  v_is_microsoft := v_provider in ('azure', 'azuread', 'microsoft', 'entra');

  if not public.is_corporate_email_allowed(v_email) then
    update public.profiles
    set access_status = 'bloqueado',
        status_reason = 'E-mail fora do domínio corporativo autorizado.',
        status_changed_at = now(),
        updated_at = now()
    where id = auth.uid();

    insert into public.access_audit_log(entity_type, entity_id, action, actor_user_id, new_values)
    values ('user_access', auth.uid()::text, 'session_denied_domain', auth.uid(),
      jsonb_build_object('email', v_email, 'provider', v_provider));

    return jsonb_build_object('allowed', false, 'reason', 'domain_not_allowed',
      'message', 'Acesso permitido apenas para contas corporativas Biotrop.');
  end if;

  select * into v_exception
  from public.corporate_access_allowlist a
  where lower(a.email) = v_email
    and a.enabled
    and (a.expires_at is null or a.expires_at > now())
  limit 1;

  if not v_is_microsoft
     and coalesce(v_settings.password_login_mode, 'exceptions') = 'disabled'
     and v_exception.id is null then
    insert into public.access_audit_log(entity_type, entity_id, action, actor_user_id, new_values)
    values ('user_access', auth.uid()::text, 'session_denied_password_mode', auth.uid(),
      jsonb_build_object('email', v_email, 'provider', v_provider));

    return jsonb_build_object('allowed', false, 'reason', 'password_login_disabled',
      'message', 'O acesso por senha foi desativado. Entre com sua conta Microsoft Biotrop.');
  end if;

  v_claim_name := coalesce(
    nullif(v_user.raw_user_meta_data ->> 'full_name', ''),
    nullif(v_user.raw_user_meta_data ->> 'name', '')
  );
  v_claim_oid := coalesce(
    nullif(v_user.raw_user_meta_data ->> 'provider_id', ''),
    nullif(v_user.raw_user_meta_data ->> 'sub', '')
  );

  update public.profiles p
  set name = coalesce(nullif(p.name, ''), v_claim_name, p.name),
      full_name = coalesce(v_claim_name, p.full_name),
      email = coalesce(v_user.email, p.email),
      auth_provider = v_provider,
      azure_oid = case when v_is_microsoft then coalesce(p.azure_oid, v_claim_oid) else p.azure_oid end,
      azure_tenant_id = case when v_is_microsoft then coalesce(p.azure_tenant_id, nullif(v_settings.entra_tenant_id, '')) else p.azure_tenant_id end,
      last_login = now(),
      updated_at = now()
  where p.id = auth.uid();

  select * into v_profile from public.profiles where id = auth.uid();

  if coalesce(v_profile.access_status, 'inativo') <> 'ativo' then
    return jsonb_build_object(
      'allowed', false,
      'reason', 'profile_' || coalesce(v_profile.access_status, 'inativo'),
      'access_status', v_profile.access_status,
      'message', case coalesce(v_profile.access_status, 'inativo')
        when 'inativo' then 'Sua conta foi criada e está aguardando liberação de perfil pelo administrador.'
        when 'bloqueado' then coalesce(v_profile.status_reason, 'Acesso bloqueado. Fale com o administrador do sistema.')
        when 'afastado' then 'Conta marcada como afastada. Fale com Gente & Gestão.'
        when 'desligado' then 'Conta encerrada. Acesso indisponível.'
        else 'Acesso indisponível. Fale com o administrador do sistema.'
      end
    );
  end if;

  insert into public.access_audit_log(entity_type, entity_id, action, actor_user_id, new_values)
  values ('user_access', auth.uid()::text, 'session_granted', auth.uid(),
    jsonb_build_object('provider', v_provider));

  return jsonb_build_object(
    'allowed', true,
    'provider', v_provider,
    'access_status', v_profile.access_status,
    'role_code', v_profile.role_code,
    'name', v_profile.name,
    'email', v_profile.email
  );
end;
$$;

revoke all on function public.guard_corporate_session() from public;
grant execute on function public.guard_corporate_session() to authenticated;

-- ============================================================================
-- 10. GESTÃO DE USUÁRIOS — CONSULTAS
-- ============================================================================

create or replace function public.admin_user_directory(
  p_search text default null,
  p_role_code text default null,
  p_status text default null,
  p_group_code text default null,
  p_department text default null,
  p_limit integer default 100,
  p_offset integer default 0
)
returns jsonb
language plpgsql
stable
security definer
set search_path = pg_catalog, public
as $$
declare
  v_search text := nullif(lower(trim(coalesce(p_search, ''))), '');
  v_limit integer := least(greatest(coalesce(p_limit, 100), 1), 500);
  v_offset integer := greatest(coalesce(p_offset, 0), 0);
  v_total integer;
  v_rows jsonb;
begin
  if not public.has_permission('users.view') then
    raise exception using errcode = '42501', message = 'Sem permissão para consultar usuários.';
  end if;


  with filtered as (
    select p.id
    from public.profiles p
    left join public.user_roles ur on ur.user_id = p.id and ur.active
    left join public.roles r on r.id = ur.role_id
    where (v_search is null
        or lower(coalesce(p.name, '')) like '%' || v_search || '%'
        or lower(coalesce(p.full_name, '')) like '%' || v_search || '%'
        or lower(coalesce(p.email, '')) like '%' || v_search || '%'
        or lower(coalesce(p.employee_id, '')) like '%' || v_search || '%'
        or lower(coalesce(p.department, '')) like '%' || v_search || '%')
      and (nullif(p_role_code, '') is null or coalesce(r.code, p.role_code) = p_role_code)
      and (nullif(p_status, '') is null or coalesce(p.access_status, 'inativo') = p_status)
      and (nullif(p_department, '') is null or coalesce(p.department, '') = p_department)
      and (nullif(p_group_code, '') is null or exists (
        select 1 from public.access_group_members gm
        join public.access_groups g on g.id = gm.group_id
        where gm.user_id = p.id and g.code = p_group_code
      ))
  )
  select count(*) into v_total from filtered;

  select coalesce(jsonb_agg(row_data order by sort_name), '[]'::jsonb)
  into v_rows
  from (
    select
      coalesce(p.name, p.email) as sort_name,
      jsonb_build_object(
        'id', p.id,
        'name', coalesce(p.name, p.full_name, split_part(coalesce(p.email, ''), '@', 1)),
        'email', p.email,
        'department', p.department,
        'sector', p.sector,
        'job_title', p.job_title,
        'employee_id', p.employee_id,
        'phone', p.phone,
        'role_code', coalesce(r.code, p.role_code, 'viewer'),
        'role_name', r.name,
        'access_status', coalesce(p.access_status, 'inativo'),
        'status_reason', p.status_reason,
        'active', coalesce(p.active, false) and coalesce(p.is_active, false),
        'auth_provider', p.auth_provider,
        'azure_oid', p.azure_oid,
        'last_login', p.last_login,
        'created_at', p.created_at,
        'entra_synced_at', p.entra_synced_at,
        'manager_id', p.manager_id,
        'manager_email', p.manager_email,
        'manager_name', m.name,
        'in_entra', ed.azure_oid is not null,
        'entra_enabled', ed.account_enabled,
        'groups', coalesce((
          select jsonb_agg(jsonb_build_object('code', g.code, 'name', g.name) order by g.name)
          from public.access_group_members gm
          join public.access_groups g on g.id = gm.group_id
          where gm.user_id = p.id
        ), '[]'::jsonb)
      ) as row_data
    from public.profiles p
    left join public.user_roles ur on ur.user_id = p.id and ur.active
    left join public.roles r on r.id = ur.role_id
    left join public.profiles m on m.id = p.manager_id
    left join public.entra_directory ed on lower(ed.email) = lower(p.email)
    where (v_search is null
        or lower(coalesce(p.name, '')) like '%' || v_search || '%'
        or lower(coalesce(p.full_name, '')) like '%' || v_search || '%'
        or lower(coalesce(p.email, '')) like '%' || v_search || '%'
        or lower(coalesce(p.employee_id, '')) like '%' || v_search || '%'
        or lower(coalesce(p.department, '')) like '%' || v_search || '%')
      and (nullif(p_role_code, '') is null or coalesce(r.code, p.role_code) = p_role_code)
      and (nullif(p_status, '') is null or coalesce(p.access_status, 'inativo') = p_status)
      and (nullif(p_department, '') is null or coalesce(p.department, '') = p_department)
      and (nullif(p_group_code, '') is null or exists (
        select 1 from public.access_group_members gm
        join public.access_groups g on g.id = gm.group_id
        where gm.user_id = p.id and g.code = p_group_code
      ))
    order by coalesce(p.name, p.email)
    limit v_limit offset v_offset
  ) page;

  return jsonb_build_object(
    'total', v_total,
    'limit', v_limit,
    'offset', v_offset,
    'rows', v_rows,
    'can_manage', public.has_permission('users.manage'),
    'can_manage_roles', public.has_permission('roles.manage'),
    'kpis', jsonb_build_object(
      'total', (select count(*) from public.profiles),
      'ativos', (select count(*) from public.profiles where coalesce(access_status, 'inativo') = 'ativo'),
      'pendentes', (select count(*) from public.profiles where coalesce(access_status, 'inativo') = 'inativo'),
      'bloqueados', (select count(*) from public.profiles where coalesce(access_status, 'inativo') in ('bloqueado', 'desligado')),
      'afastados', (select count(*) from public.profiles where coalesce(access_status, 'inativo') = 'afastado'),
      'microsoft', (select count(*) from public.profiles where lower(coalesce(auth_provider, '')) in ('azure', 'azuread', 'microsoft', 'entra')),
      'senha', (select count(*) from public.profiles where lower(coalesce(auth_provider, 'email')) not in ('azure', 'azuread', 'microsoft', 'entra')),
      'sem_acesso_30d', (select count(*) from public.profiles where coalesce(access_status, 'inativo') = 'ativo' and (last_login is null or last_login < now() - interval '30 days')),
      'entra_total', (select count(*) from public.entra_directory)
    ),
    'roles', coalesce((
      select jsonb_agg(jsonb_build_object('code', r.code, 'name', r.name) order by r.name)
      from public.roles r where r.active
    ), '[]'::jsonb),
    'groups', coalesce((
      select jsonb_agg(jsonb_build_object(
        'id', g.id, 'code', g.code, 'name', g.name, 'kind', g.kind, 'active', g.active,
        'members', (select count(*) from public.access_group_members gm where gm.group_id = g.id)
      ) order by g.kind, g.name)
      from public.access_groups g
    ), '[]'::jsonb),
    'departments', coalesce((
      select jsonb_agg(distinct d.department)
      from (select nullif(trim(department), '') as department from public.profiles) d
      where d.department is not null
    ), '[]'::jsonb),
    'last_sync', (
      select jsonb_build_object(
        'status', s.status, 'started_at', s.started_at, 'finished_at', s.finished_at,
        'users_fetched', s.users_fetched, 'profiles_updated', s.profiles_updated,
        'managers_linked', s.managers_linked, 'error_message', s.error_message
      )
      from public.entra_sync_runs s order by s.started_at desc limit 1
    ),
    'settings', (
      select jsonb_build_object(
        'password_login_mode', s.password_login_mode,
        'auto_provision', s.auto_provision,
        'auto_activate', s.auto_activate,
        'default_role_code', s.default_role_code,
        'entra_tenant_id', s.entra_tenant_id
      )
      from public.corporate_access_settings s where s.id
    ),
    'domains', coalesce((
      select jsonb_agg(jsonb_build_object('domain', d.domain, 'enabled', d.enabled, 'description', d.description) order by d.domain)
      from public.corporate_allowed_domains d
    ), '[]'::jsonb)
  );
end;
$$;

revoke all on function public.admin_user_directory(text, text, text, text, text, integer, integer) from public;
grant execute on function public.admin_user_directory(text, text, text, text, text, integer, integer) to authenticated;

-- ============================================================================
-- 11. GESTÃO DE USUÁRIOS — ESCRITA
-- ============================================================================

create or replace function public.admin_update_user_profile(
  p_user_id uuid,
  p_patch jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = pg_catalog, public
as $$
declare
  v_old jsonb;
  v_new jsonb;
  v_manager_id uuid;
  v_status text;
begin
  if not public.has_permission('users.manage') then
    raise exception using errcode = '42501', message = 'Sem permissão para alterar usuários.';
  end if;
  if p_user_id is null or not exists (select 1 from public.profiles where id = p_user_id) then
    raise exception using errcode = '22023', message = 'Usuário não encontrado.';
  end if;
  if exists (
    select 1 from public.user_roles ur join public.roles r on r.id = ur.role_id
    where ur.user_id = p_user_id and ur.active and r.code = 'super_admin'
  ) and not public.has_permission('roles.manage') then
    raise exception using errcode = '42501', message = 'Somente um super administrador pode alterar outro super administrador.';
  end if;

  v_status := nullif(trim(coalesce(p_patch ->> 'access_status', '')), '');
  if v_status is not null and v_status not in ('ativo', 'inativo', 'bloqueado', 'afastado', 'desligado') then
    raise exception using errcode = '22023', message = 'Situação de acesso inválida.';
  end if;
  if p_user_id = auth.uid() and v_status is not null and v_status <> 'ativo' then
    raise exception using errcode = '22023', message = 'Não é permitido bloquear a própria conta.';
  end if;

  if p_patch ? 'manager_email' then
    select id into v_manager_id from public.profiles
    where lower(email) = lower(nullif(trim(p_patch ->> 'manager_email'), ''));
  end if;

  select to_jsonb(p) into v_old from public.profiles p where p.id = p_user_id;

  update public.profiles p
  set name = coalesce(nullif(trim(p_patch ->> 'name'), ''), p.name),
      full_name = coalesce(nullif(trim(p_patch ->> 'name'), ''), p.full_name),
      department = case when p_patch ? 'department' then nullif(trim(p_patch ->> 'department'), '') else p.department end,
      sector = case when p_patch ? 'sector' then nullif(trim(p_patch ->> 'sector'), '') else p.sector end,
      job_title = case when p_patch ? 'job_title' then nullif(trim(p_patch ->> 'job_title'), '') else p.job_title end,
      employee_id = case when p_patch ? 'employee_id' then nullif(trim(p_patch ->> 'employee_id'), '') else p.employee_id end,
      phone = case when p_patch ? 'phone' then nullif(trim(p_patch ->> 'phone'), '') else p.phone end,
      office_location = case when p_patch ? 'office_location' then nullif(trim(p_patch ->> 'office_location'), '') else p.office_location end,
      manager_email = case when p_patch ? 'manager_email' then nullif(trim(p_patch ->> 'manager_email'), '') else p.manager_email end,
      manager_id = case when p_patch ? 'manager_email' then v_manager_id else p.manager_id end,
      access_status = coalesce(v_status, p.access_status),
      status_reason = case
        when v_status is not null then nullif(trim(coalesce(p_patch ->> 'status_reason', '')), '')
        else p.status_reason
      end,
      status_changed_by = case when v_status is not null then auth.uid() else p.status_changed_by end,
      updated_at = now()
  where p.id = p_user_id;

  select to_jsonb(p) into v_new from public.profiles p where p.id = p_user_id;

  insert into public.access_audit_log(entity_type, entity_id, action, actor_user_id, old_values, new_values)
  values ('user_access', p_user_id::text, 'update_profile', auth.uid(),
    v_old - 'updated_at', v_new - 'updated_at');

  return v_new;
end;
$$;

revoke all on function public.admin_update_user_profile(uuid, jsonb) from public;
grant execute on function public.admin_update_user_profile(uuid, jsonb) to authenticated;

create or replace function public.admin_set_user_groups(
  p_user_id uuid,
  p_group_codes text[]
)
returns jsonb
language plpgsql
security definer
set search_path = pg_catalog, public
as $$
declare
  v_old jsonb;
  v_new jsonb;
begin
  if not public.has_permission('users.manage') then
    raise exception using errcode = '42501', message = 'Sem permissão para alterar grupos.';
  end if;

  select coalesce(jsonb_agg(g.code order by g.code), '[]'::jsonb) into v_old
  from public.access_group_members gm join public.access_groups g on g.id = gm.group_id
  where gm.user_id = p_user_id;

  delete from public.access_group_members gm
  where gm.user_id = p_user_id
    and gm.group_id not in (
      select g.id from public.access_groups g where g.code = any(coalesce(p_group_codes, array[]::text[]))
    );

  insert into public.access_group_members(group_id, user_id, assigned_by)
  select g.id, p_user_id, auth.uid()
  from public.access_groups g
  where g.code = any(coalesce(p_group_codes, array[]::text[]))
  on conflict (group_id, user_id) do nothing;

  select coalesce(jsonb_agg(g.code order by g.code), '[]'::jsonb) into v_new
  from public.access_group_members gm join public.access_groups g on g.id = gm.group_id
  where gm.user_id = p_user_id;

  insert into public.access_audit_log(entity_type, entity_id, action, actor_user_id, old_values, new_values)
  values ('user_groups', p_user_id::text, 'set_groups', auth.uid(),
    jsonb_build_object('groups', v_old), jsonb_build_object('groups', v_new));

  return jsonb_build_object('user_id', p_user_id, 'groups', v_new);
end;
$$;

revoke all on function public.admin_set_user_groups(uuid, text[]) from public;
grant execute on function public.admin_set_user_groups(uuid, text[]) to authenticated;

create or replace function public.admin_upsert_access_group(
  p_code text,
  p_name text,
  p_description text default null,
  p_kind text default 'funcao',
  p_active boolean default true
)
returns jsonb
language plpgsql
security definer
set search_path = pg_catalog, public
as $$
declare
  v_code text := lower(regexp_replace(trim(coalesce(p_code, '')), '[^a-z0-9_]+', '_', 'g'));
  v_group public.access_groups;
begin
  if not public.has_permission('users.manage') then
    raise exception using errcode = '42501', message = 'Sem permissão para gerenciar grupos.';
  end if;
  if v_code = '' or nullif(trim(coalesce(p_name, '')), '') is null then
    raise exception using errcode = '22023', message = 'Código e nome do grupo são obrigatórios.';
  end if;
  if coalesce(p_kind, 'funcao') not in ('funcao', 'setor', 'unidade', 'custom') then
    raise exception using errcode = '22023', message = 'Tipo de grupo inválido.';
  end if;

  insert into public.access_groups(code, name, description, kind, active)
  values (v_code, trim(p_name), nullif(trim(coalesce(p_description, '')), ''), coalesce(p_kind, 'funcao'), coalesce(p_active, true))
  on conflict (code) do update
  set name = excluded.name,
      description = excluded.description,
      kind = excluded.kind,
      active = excluded.active,
      updated_at = now()
  returning * into v_group;

  insert into public.access_audit_log(entity_type, entity_id, action, actor_user_id, new_values)
  values ('access_group', v_group.id::text, 'upsert_group', auth.uid(), to_jsonb(v_group));

  return to_jsonb(v_group);
end;
$$;

revoke all on function public.admin_upsert_access_group(text, text, text, text, boolean) from public;
grant execute on function public.admin_upsert_access_group(text, text, text, text, boolean) to authenticated;

create or replace function public.admin_upsert_login_exception(
  p_email text,
  p_display_name text default null,
  p_allow_password_login boolean default true,
  p_note text default null,
  p_expires_at timestamptz default null,
  p_enabled boolean default true
)
returns jsonb
language plpgsql
security definer
set search_path = pg_catalog, public
as $$
declare
  v_email text := lower(trim(coalesce(p_email, '')));
  v_row public.corporate_access_allowlist;
begin
  if not public.has_permission('users.manage') then
    raise exception using errcode = '42501', message = 'Sem permissão para gerenciar exceções de login.';
  end if;
  if v_email = '' or v_email not like '%@%.%' then
    raise exception using errcode = '22023', message = 'Informe um e-mail válido.';
  end if;

  insert into public.corporate_access_allowlist(
    email, display_name, allow_password_login, note, expires_at, enabled, created_by
  )
  values (v_email, nullif(trim(coalesce(p_display_name, '')), ''), coalesce(p_allow_password_login, true),
          nullif(trim(coalesce(p_note, '')), ''), p_expires_at, coalesce(p_enabled, true), auth.uid())
  on conflict (email) do update
  set display_name = excluded.display_name,
      allow_password_login = excluded.allow_password_login,
      note = excluded.note,
      expires_at = excluded.expires_at,
      enabled = excluded.enabled,
      updated_at = now()
  returning * into v_row;

  insert into public.access_audit_log(entity_type, entity_id, action, actor_user_id, new_values)
  values ('login_exception', v_row.id::text, 'upsert_exception', auth.uid(), to_jsonb(v_row));

  return to_jsonb(v_row);
end;
$$;

revoke all on function public.admin_upsert_login_exception(text, text, boolean, text, timestamptz, boolean) from public;
grant execute on function public.admin_upsert_login_exception(text, text, boolean, text, timestamptz, boolean) to authenticated;

create or replace function public.admin_delete_login_exception(p_email text)
returns boolean
language plpgsql
security definer
set search_path = pg_catalog, public
as $$
declare
  v_row public.corporate_access_allowlist;
begin
  if not public.has_permission('users.manage') then
    raise exception using errcode = '42501', message = 'Sem permissão para gerenciar exceções de login.';
  end if;

  delete from public.corporate_access_allowlist
  where lower(email) = lower(trim(coalesce(p_email, '')))
  returning * into v_row;

  if v_row.id is null then
    return false;
  end if;

  insert into public.access_audit_log(entity_type, entity_id, action, actor_user_id, old_values)
  values ('login_exception', v_row.id::text, 'delete_exception', auth.uid(), to_jsonb(v_row));

  return true;
end;
$$;

revoke all on function public.admin_delete_login_exception(text) from public;
grant execute on function public.admin_delete_login_exception(text) to authenticated;

create or replace function public.admin_list_login_exceptions()
returns jsonb
language plpgsql
stable
security definer
set search_path = pg_catalog, public
as $$
begin
  if not public.has_permission('users.view') then
    raise exception using errcode = '42501', message = 'Sem permissão para consultar exceções de login.';
  end if;

  return coalesce((
    select jsonb_agg(jsonb_build_object(
      'id', a.id, 'email', a.email, 'display_name', a.display_name,
      'allow_password_login', a.allow_password_login, 'enabled', a.enabled,
      'note', a.note, 'expires_at', a.expires_at, 'created_at', a.created_at,
      'expired', a.expires_at is not null and a.expires_at <= now(),
      'has_account', exists (select 1 from public.profiles p where lower(p.email) = lower(a.email))
    ) order by a.email)
    from public.corporate_access_allowlist a
  ), '[]'::jsonb);
end;
$$;

revoke all on function public.admin_list_login_exceptions() from public;
grant execute on function public.admin_list_login_exceptions() to authenticated;

create or replace function public.admin_update_access_settings(p_patch jsonb)
returns jsonb
language plpgsql
security definer
set search_path = pg_catalog, public
as $$
declare
  v_old jsonb;
  v_new jsonb;
  v_mode text := nullif(trim(coalesce(p_patch ->> 'password_login_mode', '')), '');
begin
  if not public.has_permission('roles.manage') then
    raise exception using errcode = '42501', message = 'Somente um super administrador pode alterar a política de acesso.';
  end if;
  if v_mode is not null and v_mode not in ('disabled', 'exceptions', 'open') then
    raise exception using errcode = '22023', message = 'Modo de login por senha inválido.';
  end if;

  select to_jsonb(s) into v_old from public.corporate_access_settings s where s.id;

  update public.corporate_access_settings s
  set password_login_mode = coalesce(v_mode, s.password_login_mode),
      auto_provision = coalesce((p_patch ->> 'auto_provision')::boolean, s.auto_provision),
      auto_activate = coalesce((p_patch ->> 'auto_activate')::boolean, s.auto_activate),
      default_role_code = coalesce(nullif(trim(coalesce(p_patch ->> 'default_role_code', '')), ''), s.default_role_code),
      entra_tenant_id = case when p_patch ? 'entra_tenant_id' then nullif(trim(p_patch ->> 'entra_tenant_id'), '') else s.entra_tenant_id end,
      updated_at = now(),
      updated_by = auth.uid()
  where s.id;

  select to_jsonb(s) into v_new from public.corporate_access_settings s where s.id;

  insert into public.access_audit_log(entity_type, entity_id, action, actor_user_id, old_values, new_values)
  values ('access_settings', 'singleton', 'update_settings', auth.uid(), v_old, v_new);

  return v_new;
end;
$$;

revoke all on function public.admin_update_access_settings(jsonb) from public;
grant execute on function public.admin_update_access_settings(jsonb) to authenticated;

create or replace function public.admin_access_audit(
  p_limit integer default 100,
  p_entity_type text default null,
  p_user_id uuid default null
)
returns jsonb
language plpgsql
stable
security definer
set search_path = pg_catalog, public
as $$
begin
  if not public.has_permission('audit.view') and not public.has_permission('users.manage') then
    raise exception using errcode = '42501', message = 'Sem permissão para consultar a auditoria.';
  end if;

  return coalesce((
    select jsonb_agg(jsonb_build_object(
      'id', l.id, 'entity_type', l.entity_type, 'entity_id', l.entity_id,
      'action', l.action, 'occurred_at', l.occurred_at,
      'actor_name', coalesce(a.name, a.email, 'sistema'),
      'target_name', coalesce(t.name, t.email, l.entity_id),
      'old_values', l.old_values, 'new_values', l.new_values
    ) order by l.occurred_at desc)
    from (
      select * from public.access_audit_log l2
      where (nullif(p_entity_type, '') is null or l2.entity_type = p_entity_type)
        and (p_user_id is null or l2.entity_id = p_user_id::text or l2.actor_user_id = p_user_id)
      order by l2.occurred_at desc
      limit least(greatest(coalesce(p_limit, 100), 1), 500)
    ) l
    left join public.profiles a on a.id = l.actor_user_id
    left join public.profiles t on t.id::text = l.entity_id
  ), '[]'::jsonb);
end;
$$;

revoke all on function public.admin_access_audit(integer, text, uuid) from public;
grant execute on function public.admin_access_audit(integer, text, uuid) to authenticated;

-- ============================================================================
-- 12. APLICAR DIRETÓRIO ENTRA NOS PERFIS
-- ============================================================================

create or replace function public.apply_entra_directory_to_profiles(p_overwrite boolean default false)
returns jsonb
language plpgsql
security definer
set search_path = pg_catalog, public
as $$
declare
  v_updated integer := 0;
  v_managers integer := 0;
  v_blocked integer := 0;
begin
  -- Aceita o administrador logado ou o backend com a service role
  -- (chaves novas sb_secret_* chegam sem claim de JWT, daí o session_user).
  if not public.has_permission('users.manage')
     and coalesce(auth.role(), '') <> 'service_role'
     and session_user <> 'service_role' then
    raise exception using errcode = '42501', message = 'Sem permissão para aplicar o diretório corporativo.';
  end if;

  update public.profiles p
  set name = case when p_overwrite then coalesce(nullif(d.display_name, ''), p.name) else coalesce(nullif(p.name, ''), nullif(d.display_name, ''), p.name) end,
      full_name = coalesce(nullif(d.display_name, ''), p.full_name),
      department = case when p_overwrite then coalesce(nullif(d.department, ''), p.department) else coalesce(nullif(p.department, ''), nullif(d.department, '')) end,
      sector = case when p_overwrite then coalesce(nullif(d.department, ''), p.sector) else coalesce(nullif(p.sector, ''), nullif(d.department, '')) end,
      job_title = case when p_overwrite then coalesce(nullif(d.job_title, ''), p.job_title) else coalesce(nullif(p.job_title, ''), nullif(d.job_title, '')) end,
      employee_id = case when p_overwrite then coalesce(nullif(d.employee_id, ''), p.employee_id) else coalesce(nullif(p.employee_id, ''), nullif(d.employee_id, '')) end,
      office_location = case when p_overwrite then coalesce(nullif(d.office_location, ''), p.office_location) else coalesce(nullif(p.office_location, ''), nullif(d.office_location, '')) end,
      phone = case when p_overwrite then coalesce(nullif(d.mobile_phone, ''), nullif(d.business_phone, ''), p.phone) else coalesce(nullif(p.phone, ''), nullif(d.mobile_phone, ''), nullif(d.business_phone, '')) end,
      manager_email = coalesce(nullif(d.manager_email, ''), p.manager_email),
      azure_oid = coalesce(p.azure_oid, d.azure_oid),
      entra_synced_at = now(),
      updated_at = now()
  from public.entra_directory d
  where lower(d.email) = lower(p.email);
  get diagnostics v_updated = row_count;

  update public.profiles p
  set manager_id = m.id, updated_at = now()
  from public.profiles m
  where p.manager_email is not null
    and lower(m.email) = lower(p.manager_email)
    and (p.manager_id is null or p.manager_id <> m.id)
    and m.id <> p.id;
  get diagnostics v_managers = row_count;

  -- Conta desativada no Entra perde o acesso ao portal automaticamente.
  update public.profiles p
  set access_status = 'bloqueado',
      status_reason = 'Conta desativada no Microsoft Entra ID.',
      status_changed_at = now(),
      updated_at = now()
  from public.entra_directory d
  where lower(d.email) = lower(p.email)
    and d.account_enabled is false
    and coalesce(p.access_status, 'inativo') = 'ativo';
  get diagnostics v_blocked = row_count;

  return jsonb_build_object('profiles_updated', v_updated, 'managers_linked', v_managers, 'blocked_by_entra', v_blocked);
end;
$$;

revoke all on function public.apply_entra_directory_to_profiles(boolean) from public;
grant execute on function public.apply_entra_directory_to_profiles(boolean) to authenticated, service_role;

-- ============================================================================
-- 13. VISÃO DO GESTOR (equipe direta) — base do painel de treinamentos
-- ============================================================================

create or replace function public.get_my_team()
returns jsonb
language plpgsql
stable
security definer
set search_path = pg_catalog, public
as $$
begin
  if auth.uid() is null then
    return '[]'::jsonb;
  end if;

  return coalesce((
    select jsonb_agg(jsonb_build_object(
      'id', p.id, 'name', p.name, 'email', p.email,
      'job_title', p.job_title, 'department', p.department,
      'access_status', p.access_status, 'last_login', p.last_login,
      'role_code', p.role_code,
      'groups', coalesce((
        select jsonb_agg(g.code order by g.code)
        from public.access_group_members gm join public.access_groups g on g.id = gm.group_id
        where gm.user_id = p.id
      ), '[]'::jsonb)
    ) order by p.name)
    from public.profiles p
    where p.manager_id = auth.uid()
  ), '[]'::jsonb);
end;
$$;

revoke all on function public.get_my_team() from public;
grant execute on function public.get_my_team() to authenticated;

-- ============================================================================
-- 14. RLS
-- ============================================================================

drop policy if exists access_groups_select on public.access_groups;
create policy access_groups_select on public.access_groups
  for select to authenticated using (true);

drop policy if exists access_groups_manage on public.access_groups;
create policy access_groups_manage on public.access_groups
  for all to authenticated
  using (public.has_permission('users.manage'))
  with check (public.has_permission('users.manage'));

drop policy if exists access_group_members_select on public.access_group_members;
create policy access_group_members_select on public.access_group_members
  for select to authenticated
  using (user_id = auth.uid() or public.has_permission('users.view'));

drop policy if exists access_group_members_manage on public.access_group_members;
create policy access_group_members_manage on public.access_group_members
  for all to authenticated
  using (public.has_permission('users.manage'))
  with check (public.has_permission('users.manage'));

drop policy if exists entra_directory_select on public.entra_directory;
create policy entra_directory_select on public.entra_directory
  for select to authenticated using (public.has_permission('users.view'));

drop policy if exists entra_sync_runs_select on public.entra_sync_runs;
create policy entra_sync_runs_select on public.entra_sync_runs
  for select to authenticated using (public.has_permission('users.view'));

drop policy if exists corporate_domains_select on public.corporate_allowed_domains;
create policy corporate_domains_select on public.corporate_allowed_domains
  for select to authenticated using (true);

drop policy if exists corporate_domains_manage on public.corporate_allowed_domains;
create policy corporate_domains_manage on public.corporate_allowed_domains
  for all to authenticated
  using (public.has_permission('roles.manage'))
  with check (public.has_permission('roles.manage'));

drop policy if exists corporate_settings_select on public.corporate_access_settings;
create policy corporate_settings_select on public.corporate_access_settings
  for select to authenticated using (public.has_permission('users.view'));

drop policy if exists corporate_access_admin_all on public.corporate_access_allowlist;
create policy corporate_access_admin_all on public.corporate_access_allowlist
  for all to authenticated
  using (public.has_permission('users.manage'))
  with check (public.has_permission('users.manage'));

-- ============================================================================
-- 15. PONTE DE MIGRAÇÃO — evita perda de acesso no dia da virada
-- ============================================================================

-- Contas de senha que já usam o sistema entram na allowlist como exceção,
-- para revisão e remoção gradual pelo administrador.
insert into public.corporate_access_allowlist(email, display_name, allow_password_login, note, enabled)
select
  lower(p.email),
  coalesce(p.name, p.full_name),
  true,
  'Exceção criada na migração para login Microsoft. Revisar e remover após a conta Microsoft ser usada.',
  true
from public.profiles p
where p.email is not null
  and lower(coalesce(p.auth_provider, 'email')) not in ('azure', 'azuread', 'microsoft', 'entra')
  and (p.last_login is not null or coalesce(p.role_code, 'viewer') <> 'viewer')
on conflict (email) do nothing;

commit;

-- ============================================================================
-- PÓS-INSTALAÇÃO (execute manualmente conforme necessário)
-- ============================================================================
-- 1) Registre o tenant do Entra ID (aparece na tela de administração):
--    select public.admin_update_access_settings('{"entra_tenant_id":"<TENANT_ID>"}'::jsonb);
--
-- 2) Para desligar o login por senha de vez (após todos migrarem):
--    select public.admin_update_access_settings('{"password_login_mode":"disabled"}'::jsonb);
--
-- 3) Para exigir liberação manual de cada novo colaborador:
--    select public.admin_update_access_settings('{"auto_activate":false}'::jsonb);
--
-- 4) Garanta seu super admin (a conta precisa existir no Auth):
--    select public.bootstrap_biotrop_super_admin('felipe.vieira@biotrop.com.br');
