import { Router, type Request, type Response } from 'express';
import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { requireAuth, requirePermission } from './authMiddleware';

/**
 * Sincronização do diretório corporativo (Microsoft Entra ID) via Microsoft Graph.
 * Requer, no App Registration, a permissão de aplicativo User.Read.All com consentimento
 * do administrador. Somente contas dos domínios autorizados são armazenadas.
 */

type EntraConfig = { tenantId: string; clientId: string; clientSecret: string };

type GraphUser = {
  id: string;
  displayName?: string | null;
  givenName?: string | null;
  surname?: string | null;
  mail?: string | null;
  userPrincipalName?: string | null;
  jobTitle?: string | null;
  department?: string | null;
  officeLocation?: string | null;
  employeeId?: string | null;
  mobilePhone?: string | null;
  businessPhones?: string[] | null;
  accountEnabled?: boolean | null;
  manager?: { id?: string; mail?: string | null; userPrincipalName?: string | null; displayName?: string | null } | null;
};

const GRAPH_SELECT = [
  'id', 'displayName', 'givenName', 'surname', 'mail', 'userPrincipalName',
  'jobTitle', 'department', 'officeLocation', 'employeeId', 'mobilePhone',
  'businessPhones', 'accountEnabled'
].join(',');

function entraConfig(): EntraConfig | null {
  const tenantId = process.env.MS_TENANT_ID || process.env.MICROSOFT_TENANT_ID || '';
  const clientId = process.env.MS_CLIENT_ID || process.env.MICROSOFT_CLIENT_ID || '';
  const clientSecret = process.env.MS_CLIENT_SECRET || process.env.MICROSOFT_CLIENT_SECRET || '';
  return tenantId && clientId && clientSecret ? { tenantId, clientId, clientSecret } : null;
}

function serviceClient(): SupabaseClient | null {
  const url = process.env.SUPABASE_URL || '';
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY || '';
  if (!url || !key) return null;
  return createClient(url, key, { auth: { autoRefreshToken: false, persistSession: false } });
}

let tokenCache: { accessToken: string; expiresAt: number } | null = null;

async function graphToken(cfg: EntraConfig): Promise<string> {
  if (tokenCache && tokenCache.expiresAt > Date.now() + 60_000) return tokenCache.accessToken;
  const response = await fetch(`https://login.microsoftonline.com/${encodeURIComponent(cfg.tenantId)}/oauth2/v2.0/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id: cfg.clientId,
      client_secret: cfg.clientSecret,
      scope: 'https://graph.microsoft.com/.default',
      grant_type: 'client_credentials'
    })
  });
  if (!response.ok) throw new Error(`Falha ao obter token do Entra ID (${response.status}): ${await response.text()}`);
  const data = await response.json() as { access_token?: string; expires_in?: number };
  if (!data.access_token) throw new Error('O Entra ID não retornou access_token.');
  tokenCache = { accessToken: data.access_token, expiresAt: Date.now() + (Number(data.expires_in || 3600) * 1000) };
  return data.access_token;
}

async function graphGet<T>(url: string, token: string): Promise<T> {
  const response = await fetch(url, { headers: { Authorization: `Bearer ${token}`, ConsistencyLevel: 'eventual' } });
  if (!response.ok) throw new Error(`Microsoft Graph ${response.status}: ${await response.text()}`);
  return await response.json() as T;
}

/** Busca todos os usuários do tenant, com o gestor quando o Graph permitir o $expand. */
async function fetchDirectory(token: string): Promise<{ users: GraphUser[]; expanded: boolean }> {
  const base = 'https://graph.microsoft.com/v1.0/users';
  const withManager = `${base}?$select=${GRAPH_SELECT}&$expand=manager($select=id,mail,userPrincipalName,displayName)&$top=500`;
  const plain = `${base}?$select=${GRAPH_SELECT}&$top=999`;

  let next: string | null = withManager;
  let expanded = true;
  const users: GraphUser[] = [];

  while (next) {
    try {
      const page = await graphGet<{ value: GraphUser[]; '@odata.nextLink'?: string }>(next, token);
      users.push(...(page.value || []));
      next = page['@odata.nextLink'] || null;
    } catch (error) {
      // Alguns tenants recusam $expand=manager em /users. Refaz sem o expand.
      if (expanded && users.length === 0) {
        expanded = false;
        next = plain;
        continue;
      }
      throw error;
    }
  }

  return { users, expanded };
}

/** Complemento: busca o gestor um a um quando o $expand não está disponível. */
async function fetchManagers(users: GraphUser[], token: string): Promise<void> {
  const chunkSize = 12;
  for (let index = 0; index < users.length; index += chunkSize) {
    const chunk = users.slice(index, index + chunkSize);
    await Promise.all(chunk.map(async user => {
      try {
        user.manager = await graphGet<GraphUser['manager']>(
          `https://graph.microsoft.com/v1.0/users/${encodeURIComponent(user.id)}/manager?$select=id,mail,userPrincipalName,displayName`,
          token
        );
      } catch {
        user.manager = null; // sem gestor definido no Entra ID
      }
    }));
  }
}

function emailOf(user: { mail?: string | null; userPrincipalName?: string | null } | null | undefined): string {
  if (!user) return '';
  return String(user.mail || user.userPrincipalName || '').trim().toLowerCase();
}

function inAllowedDomains(email: string, domains: string[]): boolean {
  if (!email.includes('@')) return false;
  if (!domains.length) return true;
  const domain = email.split('@')[1];
  return domains.includes(domain);
}

const router = Router();

router.get('/admin/entra/status', requireAuth, requirePermission('users.view'), async (req: Request, res: Response) => {
  const service = serviceClient();
  if (!service) return res.status(503).json({ error: 'SUPABASE_SERVICE_ROLE_KEY não configurada no servidor.' });

  const [{ data: lastRun }, { count: directoryCount }] = await Promise.all([
    service.from('entra_sync_runs').select('*').order('started_at', { ascending: false }).limit(1).maybeSingle(),
    service.from('entra_directory').select('azure_oid', { count: 'exact', head: true })
  ]);

  return res.json({
    data: {
      configured: Boolean(entraConfig()),
      tenant_configured: Boolean(process.env.MS_TENANT_ID || process.env.MICROSOFT_TENANT_ID),
      directory_count: directoryCount || 0,
      last_run: lastRun || null
    }
  });
});

router.post('/admin/entra/sync', requireAuth, requirePermission('users.manage'), async (req: Request, res: Response) => {
  const cfg = entraConfig();
  if (!cfg) {
    return res.status(503).json({
      error: 'Integração com o Entra ID não configurada. Defina MS_TENANT_ID, MS_CLIENT_ID e MS_CLIENT_SECRET no servidor.'
    });
  }
  const service = serviceClient();
  if (!service) return res.status(503).json({ error: 'SUPABASE_SERVICE_ROLE_KEY não configurada no servidor.' });

  const { data: run, error: runError } = await service
    .from('entra_sync_runs')
    .insert({ status: 'running', triggered_by: req.authUserId })
    .select('id')
    .single();
  if (runError) return res.status(500).json({ error: `Não foi possível registrar a sincronização: ${runError.message}` });

  const finish = async (patch: Record<string, unknown>) => {
    await service.from('entra_sync_runs').update({ finished_at: new Date().toISOString(), ...patch }).eq('id', run.id);
  };

  try {
    const { data: domainRows } = await service
      .from('corporate_allowed_domains')
      .select('domain')
      .eq('enabled', true);
    const domains = (domainRows || []).map(row => String(row.domain).toLowerCase());

    const token = await graphToken(cfg);
    const { users, expanded } = await fetchDirectory(token);
    if (!expanded) await fetchManagers(users, token);

    const rows = users
      .map(user => ({ user, email: emailOf(user) }))
      .filter(({ email }) => inAllowedDomains(email, domains))
      .map(({ user, email }) => ({
        azure_oid: user.id,
        email,
        user_principal_name: user.userPrincipalName || null,
        display_name: user.displayName || null,
        given_name: user.givenName || null,
        surname: user.surname || null,
        job_title: user.jobTitle || null,
        department: user.department || null,
        office_location: user.officeLocation || null,
        employee_id: user.employeeId || null,
        mobile_phone: user.mobilePhone || null,
        business_phone: (user.businessPhones || [])[0] || null,
        account_enabled: user.accountEnabled ?? null,
        manager_oid: user.manager?.id || null,
        manager_email: emailOf(user.manager) || null,
        manager_name: user.manager?.displayName || null,
        raw: user as unknown as Record<string, unknown>,
        synced_at: new Date().toISOString()
      }));

    let upserted = 0;
    for (let index = 0; index < rows.length; index += 400) {
      const chunk = rows.slice(index, index + 400);
      const { error } = await service.from('entra_directory').upsert(chunk, { onConflict: 'azure_oid' });
      if (error) throw new Error(`Falha ao gravar o diretório: ${error.message}`);
      upserted += chunk.length;
    }

    let applied: Record<string, number> = { profiles_updated: 0, managers_linked: 0, blocked_by_entra: 0 };
    if (req.body?.apply !== false) {
      const { data, error } = await service.rpc('apply_entra_directory_to_profiles', { p_overwrite: Boolean(req.body?.overwrite) });
      if (error) throw new Error(`Falha ao aplicar o diretório nos perfis: ${error.message}`);
      applied = (data || applied) as Record<string, number>;
    }

    await finish({
      status: 'success',
      users_fetched: users.length,
      users_upserted: upserted,
      profiles_updated: applied.profiles_updated || 0,
      managers_linked: applied.managers_linked || 0
    });

    return res.json({
      data: {
        users_fetched: users.length,
        users_stored: upserted,
        skipped_out_of_domain: users.length - rows.length,
        manager_expand_supported: expanded,
        ...applied
      }
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Erro desconhecido na sincronização.';
    await finish({ status: 'error', error_message: message });
    return res.status(502).json({ error: message });
  }
});

export default router;
