/* BIOTROP — Gestão de usuários corporativos.
   Plugado na tela de Administração existente: adiciona as abas de diretório,
   grupos, exceções de login, política de acesso e auditoria.
   Toda escrita passa por RPCs com verificação de permissão e auditoria no banco. */
(function () {
  'use strict';
  if (window.__BIOTROP_USER_MGMT_V1) return;
  window.__BIOTROP_USER_MGMT_V1 = true;

  var TABS = [
    { id: 'directory', label: 'Diretório de usuários' },
    { id: 'groups', label: 'Grupos e funções' },
    { id: 'exceptions', label: 'Exceções de login' },
    { id: 'policy', label: 'Política de acesso' },
    { id: 'audit', label: 'Auditoria' }
  ];

  var STATUS = [
    { code: 'ativo', label: 'Ativo' },
    { code: 'inativo', label: 'Aguardando liberação' },
    { code: 'bloqueado', label: 'Bloqueado' },
    { code: 'afastado', label: 'Afastado' },
    { code: 'desligado', label: 'Desligado' }
  ];

  var GROUP_KINDS = [
    { code: 'funcao', label: 'Função' },
    { code: 'setor', label: 'Setor' },
    { code: 'unidade', label: 'Unidade' },
    { code: 'custom', label: 'Outro' }
  ];

  var S = {
    tab: null,
    loading: false,
    error: '',
    data: null,
    filters: { search: '', role: '', status: '', group: '', department: '' },
    offset: 0,
    limit: 100,
    pending: {},
    exceptions: null,
    audit: null,
    searchTimer: null
  };

  function sb() { return window.SB || null; }
  function esc(v) {
    return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function toast(message, kind) {
    var node = document.createElement('div');
    node.className = 'um-toast ' + (kind === 'err' ? 'err' : 'ok');
    node.textContent = message;
    document.body.appendChild(node);
    setTimeout(function () { node.remove(); }, kind === 'err' ? 6500 : 3600);
  }

  function fmtDate(value) {
    if (!value) return '—';
    var d = new Date(value);
    if (isNaN(d.getTime())) return '—';
    return d.toLocaleDateString('pt-BR') + ' ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  }
  function fmtDay(value) {
    if (!value) return '—';
    var d = new Date(value);
    return isNaN(d.getTime()) ? '—' : d.toLocaleDateString('pt-BR');
  }
  function isMicrosoft(provider) {
    return ['azure', 'azuread', 'microsoft', 'entra'].indexOf(String(provider || '').toLowerCase()) >= 0;
  }
  function statusLabel(code) {
    for (var i = 0; i < STATUS.length; i++) if (STATUS[i].code === code) return STATUS[i].label;
    return code || 'Aguardando liberação';
  }

  async function rpc(name, args) {
    var client = sb();
    if (!client) throw new Error('Supabase não configurado.');
    var r = await client.rpc(name, args || {});
    if (r.error) {
      if (/does not exist|schema cache|could not find/i.test(r.error.message || '')) {
        throw new Error('Função ' + name + ' não encontrada no banco. Aplique database/migrations/2026-09-microsoft-entra-access.sql.');
      }
      throw new Error(r.error.message);
    }
    return r.data;
  }

  async function callApi(path, options) {
    var client = sb();
    var session = await client.auth.getSession();
    var token = session && session.data && session.data.session ? session.data.session.access_token : '';
    var base = (window.BIOTROP_CONFIG && window.BIOTROP_CONFIG.apiBaseUrl) || (window.location.origin + '/api');
    var response = await fetch(base + path, Object.assign({
      headers: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json' }
    }, options || {}));
    var payload = null;
    try { payload = await response.json(); } catch (e) { payload = null; }
    if (!response.ok) throw new Error((payload && payload.error) || ('Falha na API (' + response.status + ').'));
    return payload;
  }

  function ensureStyle() {
    if (document.getElementById('um-style-link')) return;
    var link = document.createElement('link');
    link.id = 'um-style-link';
    link.rel = 'stylesheet';
    link.href = './assets/css/user-management-v1.css?v=1';
    document.head.appendChild(link);
  }

  // ==================================================================== dados
  async function loadDirectory() {
    S.loading = true; S.error = ''; renderActive();
    try {
      S.data = await rpc('admin_user_directory', {
        p_search: S.filters.search || null,
        p_role_code: S.filters.role || null,
        p_status: S.filters.status || null,
        p_group_code: S.filters.group || null,
        p_department: S.filters.department || null,
        p_limit: S.limit,
        p_offset: S.offset
      });
      S.pending = {};
    } catch (e) {
      S.error = e.message || 'Falha ao carregar o diretório.';
    } finally {
      S.loading = false;
      renderActive();
    }
  }

  async function loadExceptions() {
    S.loading = true; S.error = ''; renderActive();
    try {
      S.exceptions = await rpc('admin_list_login_exceptions');
    } catch (e) {
      S.error = e.message || 'Falha ao carregar exceções.';
    } finally {
      S.loading = false; renderActive();
    }
  }

  async function loadAudit() {
    S.loading = true; S.error = ''; renderActive();
    try {
      S.audit = await rpc('admin_access_audit', { p_limit: 150, p_entity_type: null, p_user_id: null });
    } catch (e) {
      S.error = e.message || 'Falha ao carregar auditoria.';
    } finally {
      S.loading = false; renderActive();
    }
  }

  // =================================================================== render
  function renderKpis() {
    var k = (S.data && S.data.kpis) || {};
    var cards = [
      { label: 'Usuários', value: k.total || 0, hint: 'contas no portal', cls: '' },
      { label: 'Ativos', value: k.ativos || 0, hint: 'com acesso liberado', cls: 'good' },
      { label: 'Aguardando', value: k.pendentes || 0, hint: 'precisam de perfil', cls: 'warn' },
      { label: 'Bloqueados', value: k.bloqueados || 0, hint: 'sem acesso', cls: 'bad' },
      { label: 'Login Microsoft', value: k.microsoft || 0, hint: 'via Entra ID', cls: '' },
      { label: 'Login por senha', value: k.senha || 0, hint: 'exceções a migrar', cls: (k.senha ? 'warn' : '') },
      { label: 'Sem acesso 30d', value: k.sem_acesso_30d || 0, hint: 'ativos inativos', cls: 'warn' },
      { label: 'Entra ID', value: k.entra_total || 0, hint: 'no diretório sincronizado', cls: '' }
    ];
    return '<div class="um-kpis">' + cards.map(function (c) {
      return '<div class="um-kpi ' + c.cls + '"><small>' + esc(c.label) + '</small><strong>' + esc(c.value) +
        '</strong><span>' + esc(c.hint) + '</span></div>';
    }).join('') + '</div>';
  }

  function renderToolbar() {
    var d = S.data || {};
    var roles = d.roles || [];
    var groups = d.groups || [];
    var departments = (d.departments || []).filter(Boolean).sort();
    return '<div class="um-toolbar">' +
      '<input type="text" class="um-search" id="um-search" placeholder="Buscar por nome, e-mail, matrícula ou setor" value="' + esc(S.filters.search) + '">' +
      '<select id="um-filter-role"><option value="">Todos os perfis</option>' + roles.map(function (r) {
        return '<option value="' + esc(r.code) + '"' + (S.filters.role === r.code ? ' selected' : '') + '>' + esc(r.name) + '</option>';
      }).join('') + '</select>' +
      '<select id="um-filter-status"><option value="">Todas as situações</option>' + STATUS.map(function (s) {
        return '<option value="' + esc(s.code) + '"' + (S.filters.status === s.code ? ' selected' : '') + '>' + esc(s.label) + '</option>';
      }).join('') + '</select>' +
      '<select id="um-filter-group"><option value="">Todos os grupos</option>' + groups.map(function (g) {
        return '<option value="' + esc(g.code) + '"' + (S.filters.group === g.code ? ' selected' : '') + '>' + esc(g.name) + '</option>';
      }).join('') + '</select>' +
      '<select id="um-filter-dep"><option value="">Todos os setores</option>' + departments.map(function (dep) {
        return '<option value="' + esc(dep) + '"' + (S.filters.department === dep ? ' selected' : '') + '>' + esc(dep) + '</option>';
      }).join('') + '</select>' +
      '<span class="um-spacer"></span>' +
      '<button type="button" class="um-btn ghost" id="um-export">Exportar CSV</button>' +
      '<button type="button" class="um-btn" id="um-reload">Atualizar</button>' +
      '<button type="button" class="um-btn primary" id="um-sync">Sincronizar Entra ID</button>' +
      '</div>';
  }

  function renderDirectory() {
    var d = S.data;
    if (S.loading && !d) return '<div class="um-empty">Carregando diretório corporativo…</div>';
    if (S.error) return '<div class="um-note warn"><b>Não foi possível carregar.</b><br>' + esc(S.error) + '</div>' +
      '<button type="button" class="um-btn" id="um-reload">Tentar novamente</button>';
    if (!d) return '<div class="um-empty">Sem dados.</div>';

    var canManage = d.can_manage;
    var roles = d.roles || [];
    var rows = (d.rows || []).map(function (u) {
      var pending = S.pending[u.id] || {};
      var role = pending.role_code || u.role_code;
      var status = pending.access_status || u.access_status;
      var dirty = Object.keys(pending).length > 0;
      return '<tr data-um-row="' + esc(u.id) + '"' + (dirty ? ' class="um-dirty"' : '') + '>' +
        '<td class="um-user"><b>' + esc(u.name || '—') + '</b><span>' + esc(u.email || '—') + '</span></td>' +
        '<td>' + (isMicrosoft(u.auth_provider)
          ? '<span class="um-badge ms">Microsoft</span>'
          : '<span class="um-badge pwd">Senha</span>') +
          (u.in_entra ? '' : ' <span class="um-badge off" title="Não encontrado na última sincronização do Entra ID">fora do Entra</span>') + '</td>' +
        '<td>' + esc(u.job_title || '—') + '<br><span class="um-muted">' + esc(u.department || u.sector || '—') + '</span></td>' +
        '<td class="um-nowrap">' + esc(u.employee_id || '—') + '</td>' +
        '<td><select data-um-role="' + esc(u.id) + '"' + (canManage ? '' : ' disabled') + '>' + roles.map(function (r) {
          return '<option value="' + esc(r.code) + '"' + (r.code === role ? ' selected' : '') + '>' + esc(r.name) + '</option>';
        }).join('') + '</select></td>' +
        '<td><select data-um-status="' + esc(u.id) + '"' + (canManage ? '' : ' disabled') + '>' + STATUS.map(function (s) {
          return '<option value="' + esc(s.code) + '"' + (s.code === status ? ' selected' : '') + '>' + esc(s.label) + '</option>';
        }).join('') + '</select></td>' +
        '<td><div class="um-chips">' + ((u.groups || []).length
          ? u.groups.map(function (g) { return '<span class="um-chip">' + esc(g.name) + '</span>'; }).join('')
          : '<span class="um-muted">—</span>') + '</div></td>' +
        '<td>' + esc(u.manager_name || u.manager_email || '—') + '</td>' +
        '<td class="um-nowrap um-muted">' + esc(fmtDay(u.last_login)) + '</td>' +
        '<td><div class="um-actions">' +
          (dirty ? '<button type="button" class="um-btn sm primary" data-um-save="' + esc(u.id) + '">Salvar</button>' : '') +
          '<button type="button" class="um-btn sm" data-um-open="' + esc(u.id) + '">Detalhes</button>' +
        '</div></td>' +
      '</tr>';
    }).join('');

    var total = d.total || 0;
    var from = total ? S.offset + 1 : 0;
    var to = Math.min(S.offset + S.limit, total);
    var sync = d.last_sync;

    return renderKpis() + renderToolbar() +
      (canManage ? '' : '<div class="um-note">Você tem acesso de consulta. Alterações de perfil e situação exigem a permissão <b>users.manage</b>.</div>') +
      (sync ? '<div class="um-note">Última sincronização com o Entra ID: <b>' + esc(fmtDate(sync.finished_at || sync.started_at)) +
        '</b> — ' + esc(sync.users_fetched || 0) + ' contas lidas, ' + esc(sync.profiles_updated || 0) + ' perfis atualizados, ' +
        esc(sync.managers_linked || 0) + ' gestores vinculados.' +
        (sync.status === 'error' ? ' <b>Erro:</b> ' + esc(sync.error_message || '') : '') + '</div>'
        : '<div class="um-note">O diretório do Entra ID ainda não foi sincronizado. Cargo, setor, matrícula e gestor serão preenchidos automaticamente após a primeira sincronização.</div>') +
      '<div class="um-table-wrap"><table class="um-table"><thead><tr>' +
      '<th>Colaborador</th><th>Login</th><th>Cargo / Setor</th><th>Matrícula</th><th>Perfil</th><th>Situação</th><th>Grupos</th><th>Gestor</th><th>Último acesso</th><th></th>' +
      '</tr></thead><tbody>' + (rows || '<tr><td colspan="10" class="um-empty">Nenhum usuário encontrado com estes filtros.</td></tr>') +
      '</tbody></table></div>' +
      '<div class="um-footer"><span>Exibindo ' + from + '–' + to + ' de ' + total + ' usuários</span>' +
      '<span><button type="button" class="um-btn sm" id="um-prev"' + (S.offset <= 0 ? ' disabled' : '') + '>← Anterior</button> ' +
      '<button type="button" class="um-btn sm" id="um-next"' + (to >= total ? ' disabled' : '') + '>Próxima →</button></span></div>';
  }

  function renderGroups() {
    var d = S.data;
    if (!d) return '<div class="um-empty">Carregando…</div>';
    var groups = d.groups || [];
    var rows = groups.map(function (g) {
      return '<tr>' +
        '<td><b>' + esc(g.name) + '</b><br><span class="um-muted">' + esc(g.code) + '</span></td>' +
        '<td>' + esc((GROUP_KINDS.filter(function (k) { return k.code === g.kind; })[0] || {}).label || g.kind) + '</td>' +
        '<td>' + esc(g.members || 0) + '</td>' +
        '<td>' + (g.active ? '<span class="um-badge ativo">Ativo</span>' : '<span class="um-badge off">Inativo</span>') + '</td>' +
        '<td><div class="um-actions"><button type="button" class="um-btn sm" data-um-group-edit="' + esc(g.code) + '">Editar</button>' +
        '<button type="button" class="um-btn sm" data-um-group-filter="' + esc(g.code) + '">Ver membros</button></div></td>' +
      '</tr>';
    }).join('');

    return '<div class="um-note">Os grupos definem <b>função e setor</b> de cada colaborador. São eles que as trilhas de treinamento obrigatório usam para saber o que é exigido de cada pessoa.</div>' +
      '<div class="um-toolbar">' +
      '<input type="text" id="um-group-code" placeholder="código (ex: eletricista)">' +
      '<input type="text" id="um-group-name" placeholder="Nome do grupo">' +
      '<select id="um-group-kind">' + GROUP_KINDS.map(function (k) {
        return '<option value="' + k.code + '">' + k.label + '</option>';
      }).join('') + '</select>' +
      '<input type="text" class="um-search" id="um-group-desc" placeholder="Descrição (opcional)">' +
      '<button type="button" class="um-btn primary" id="um-group-save">Salvar grupo</button>' +
      '</div>' +
      '<div class="um-table-wrap"><table class="um-table" style="min-width:620px"><thead><tr>' +
      '<th>Grupo</th><th>Tipo</th><th>Membros</th><th>Situação</th><th></th></tr></thead><tbody>' +
      (rows || '<tr><td colspan="5" class="um-empty">Nenhum grupo cadastrado.</td></tr>') + '</tbody></table></div>';
  }

  function renderExceptions() {
    if (S.loading && !S.exceptions) return '<div class="um-empty">Carregando exceções…</div>';
    var list = S.exceptions || [];
    var mode = (S.data && S.data.settings && S.data.settings.password_login_mode) || 'exceptions';
    var rows = list.map(function (e) {
      return '<tr>' +
        '<td><b>' + esc(e.email) + '</b><br><span class="um-muted">' + esc(e.display_name || '—') + '</span></td>' +
        '<td>' + (e.allow_password_login ? '<span class="um-badge pwd">Senha liberada</span>' : '<span class="um-badge off">Somente acesso</span>') + '</td>' +
        '<td>' + (e.enabled && !e.expired ? '<span class="um-badge ativo">Vigente</span>'
          : e.expired ? '<span class="um-badge bloqueado">Expirada</span>' : '<span class="um-badge off">Desativada</span>') + '</td>' +
        '<td class="um-nowrap">' + esc(e.expires_at ? fmtDay(e.expires_at) : 'sem prazo') + '</td>' +
        '<td>' + (e.has_account ? '<span class="um-badge ativo">Sim</span>' : '<span class="um-badge off">Não</span>') + '</td>' +
        '<td class="um-muted">' + esc(e.note || '—') + '</td>' +
        '<td><div class="um-actions">' +
        '<button type="button" class="um-btn sm" data-um-exc-toggle="' + esc(e.email) + '" data-enabled="' + (e.enabled ? '1' : '0') + '">' +
        (e.enabled ? 'Desativar' : 'Reativar') + '</button>' +
        '<button type="button" class="um-btn sm danger" data-um-exc-del="' + esc(e.email) + '">Excluir</button>' +
        '</div></td></tr>';
    }).join('');

    return '<div class="um-note' + (mode === 'open' ? ' warn' : '') + '">' +
      'Modo atual de senha: <b>' + esc(mode === 'disabled' ? 'desativado (somente Microsoft)' : mode === 'open' ? 'liberado para todos' : 'somente exceções') + '</b>. ' +
      'Exceções servem para terceiros, contas de serviço e colaboradores sem conta Microsoft ativa. ' +
      'Contas que já usavam senha foram cadastradas automaticamente na migração — <b>revise e remova</b> conforme cada pessoa passar a entrar pela Microsoft.' +
      '</div>' +
      '<div class="um-toolbar">' +
      '<input type="email" class="um-search" id="um-exc-email" placeholder="e-mail@dominio.com.br">' +
      '<input type="text" id="um-exc-name" placeholder="Nome (opcional)">' +
      '<input type="text" class="um-search" id="um-exc-note" placeholder="Motivo da exceção">' +
      '<input type="date" id="um-exc-expires" title="Validade da exceção">' +
      '<label class="um-check"><input type="checkbox" id="um-exc-password" checked><span>Liberar senha</span></label>' +
      '<button type="button" class="um-btn primary" id="um-exc-save">Cadastrar exceção</button>' +
      '</div>' +
      '<div class="um-table-wrap"><table class="um-table" style="min-width:900px"><thead><tr>' +
      '<th>E-mail</th><th>Senha</th><th>Situação</th><th>Validade</th><th>Tem conta</th><th>Motivo</th><th></th>' +
      '</tr></thead><tbody>' + (rows || '<tr><td colspan="7" class="um-empty">Nenhuma exceção cadastrada. Apenas contas Microsoft do domínio corporativo têm acesso.</td></tr>') +
      '</tbody></table></div>';
  }

  function renderPolicy() {
    var d = S.data;
    if (!d) return '<div class="um-empty">Carregando…</div>';
    var s = d.settings || {};
    var domains = d.domains || [];
    var roles = d.roles || [];
    var canEdit = d.can_manage_roles;

    return '<div class="um-note">Esta política é aplicada <b>no banco de dados</b>: vale para o site, para a API e para qualquer outro cliente. O navegador apenas obedece.</div>' +
      (canEdit ? '' : '<div class="um-note warn">Somente um <b>super administrador</b> (permissão roles.manage) pode alterar a política de acesso.</div>') +
      '<div class="um-table-wrap" style="padding:20px">' +
      '<div class="um-field"><label>Domínios corporativos autorizados</label><div class="um-chips">' +
      (domains.length ? domains.map(function (dom) {
        return '<span class="um-chip">' + esc(dom.domain) + (dom.enabled ? '' : ' (desativado)') + '</span>';
      }).join('') : '<span class="um-muted">nenhum domínio configurado</span>') +
      '</div><p class="um-muted" style="font-size:11px;margin:8px 0 0">Contas fora destes domínios são recusadas na criação e na entrada, mesmo que existam no tenant como convidadas. Para alterar a lista, use a tabela <code>corporate_allowed_domains</code>.</p></div>' +
      '<div class="um-field-row">' +
      '<div class="um-field"><label>Login por senha</label><select id="um-pol-mode"' + (canEdit ? '' : ' disabled') + '>' +
      [['disabled', 'Desativado — somente Microsoft'], ['exceptions', 'Somente exceções autorizadas'], ['open', 'Liberado para todos']].map(function (o) {
        return '<option value="' + o[0] + '"' + (s.password_login_mode === o[0] ? ' selected' : '') + '>' + o[1] + '</option>';
      }).join('') + '</select></div>' +
      '<div class="um-field"><label>Perfil padrão do novo colaborador</label><select id="um-pol-role"' + (canEdit ? '' : ' disabled') + '>' +
      roles.map(function (r) {
        return '<option value="' + esc(r.code) + '"' + (s.default_role_code === r.code ? ' selected' : '') + '>' + esc(r.name) + '</option>';
      }).join('') + '</select></div>' +
      '</div>' +
      '<div class="um-field"><label>Provisionamento automático</label><div class="um-checks">' +
      '<label class="um-check"><input type="checkbox" id="um-pol-provision"' + (s.auto_provision ? ' checked' : '') + (canEdit ? '' : ' disabled') + '><span>Criar perfil no primeiro login</span></label>' +
      '<label class="um-check"><input type="checkbox" id="um-pol-activate"' + (s.auto_activate ? ' checked' : '') + (canEdit ? '' : ' disabled') + '><span>Já entrar ativo (sem espera de liberação)</span></label>' +
      '</div><p class="um-muted" style="font-size:11px;margin:8px 0 0">Desmarcar a segunda opção faz cada novo colaborador aguardar liberação manual do administrador antes de acessar qualquer módulo.</p></div>' +
      '<div class="um-field"><label>Tenant do Microsoft Entra ID</label><input type="text" id="um-pol-tenant" value="' + esc(s.entra_tenant_id || '') + '" placeholder="00000000-0000-0000-0000-000000000000"' + (canEdit ? '' : ' disabled') + '></div>' +
      (canEdit ? '<div class="um-drawer-actions" style="border:0;padding-top:6px"><button type="button" class="um-btn primary" id="um-pol-save">Salvar política</button></div>' : '') +
      '</div>';
  }

  function renderAudit() {
    if (S.loading && !S.audit) return '<div class="um-empty">Carregando auditoria…</div>';
    var list = S.audit || [];
    var rows = list.map(function (l) {
      return '<tr><td class="um-nowrap um-muted">' + esc(fmtDate(l.occurred_at)) + '</td>' +
        '<td><code>' + esc(l.action) + '</code></td>' +
        '<td>' + esc(l.target_name || '—') + '</td>' +
        '<td>' + esc(l.actor_name || 'sistema') + '</td>' +
        '<td class="um-muted">' + esc(l.entity_type) + '</td></tr>';
    }).join('');
    return '<div class="um-note">Registro imutável de acessos e alterações de permissão. É esta trilha que comprova, em auditoria, quem liberou o quê e quando.</div>' +
      '<div class="um-table-wrap"><table class="um-table um-audit" style="min-width:760px"><thead><tr>' +
      '<th>Quando</th><th>Ação</th><th>Usuário afetado</th><th>Responsável</th><th>Entidade</th>' +
      '</tr></thead><tbody>' + (rows || '<tr><td colspan="5" class="um-empty">Sem registros.</td></tr>') + '</tbody></table></div>';
  }

  // =================================================================== drawer
  function openDrawer(userId) {
    var d = S.data || {};
    var user = (d.rows || []).filter(function (u) { return u.id === userId; })[0];
    if (!user) return;
    var groups = d.groups || [];
    var assigned = (user.groups || []).map(function (g) { return g.code; });
    var canManage = d.can_manage;

    var root = document.createElement('div');
    root.className = 'um-drawer';
    root.id = 'um-drawer';
    root.innerHTML = '<div class="um-drawer-panel">' +
      '<div class="um-drawer-head"><div><h3>' + esc(user.name || 'Usuário') + '</h3><p>' + esc(user.email || '') + '</p></div>' +
      '<button type="button" class="um-close" id="um-drawer-close">×</button></div>' +
      '<div class="um-field"><label>Nome completo</label><input type="text" id="um-d-name" value="' + esc(user.name || '') + '"' + (canManage ? '' : ' disabled') + '></div>' +
      '<div class="um-field-row">' +
      '<div class="um-field"><label>Cargo</label><input type="text" id="um-d-job" value="' + esc(user.job_title || '') + '"' + (canManage ? '' : ' disabled') + '></div>' +
      '<div class="um-field"><label>Matrícula</label><input type="text" id="um-d-emp" value="' + esc(user.employee_id || '') + '"' + (canManage ? '' : ' disabled') + '></div>' +
      '</div>' +
      '<div class="um-field-row">' +
      '<div class="um-field"><label>Setor</label><input type="text" id="um-d-dep" value="' + esc(user.department || '') + '"' + (canManage ? '' : ' disabled') + '></div>' +
      '<div class="um-field"><label>Telefone</label><input type="text" id="um-d-phone" value="' + esc(user.phone || '') + '"' + (canManage ? '' : ' disabled') + '></div>' +
      '</div>' +
      '<div class="um-field"><label>E-mail do gestor</label><input type="email" id="um-d-manager" value="' + esc(user.manager_email || '') + '" placeholder="gestor@biotrop.com.br"' + (canManage ? '' : ' disabled') + '>' +
      '<p class="um-muted" style="font-size:11px;margin:6px 0 0">Define quem acompanha os treinamentos desta pessoa. Preenchido automaticamente pela sincronização do Entra ID.</p></div>' +
      '<div class="um-field-row">' +
      '<div class="um-field"><label>Situação de acesso</label><select id="um-d-status"' + (canManage ? '' : ' disabled') + '>' + STATUS.map(function (s) {
        return '<option value="' + s.code + '"' + (s.code === user.access_status ? ' selected' : '') + '>' + s.label + '</option>';
      }).join('') + '</select></div>' +
      '<div class="um-field"><label>Perfil de acesso</label><select id="um-d-role"' + (canManage ? '' : ' disabled') + '>' + (d.roles || []).map(function (r) {
        return '<option value="' + esc(r.code) + '"' + (r.code === user.role_code ? ' selected' : '') + '>' + esc(r.name) + '</option>';
      }).join('') + '</select></div>' +
      '</div>' +
      '<div class="um-field"><label>Motivo / observação da situação</label><textarea id="um-d-reason" placeholder="Ex: afastamento médico até 30/10, terceiro com contrato encerrado…"' + (canManage ? '' : ' disabled') + '>' + esc(user.status_reason || '') + '</textarea></div>' +
      '<div class="um-field"><label>Grupos (função e setor)</label><div class="um-checks">' + groups.map(function (g) {
        return '<label class="um-check"><input type="checkbox" data-um-d-group="' + esc(g.code) + '"' +
          (assigned.indexOf(g.code) >= 0 ? ' checked' : '') + (canManage ? '' : ' disabled') + '><span>' + esc(g.name) + '</span></label>';
      }).join('') + '</div></div>' +
      (canManage ? '<div class="um-drawer-actions"><button type="button" class="um-btn primary" id="um-d-save">Salvar alterações</button>' +
        '<button type="button" class="um-btn ghost" id="um-d-cancel">Cancelar</button></div>' : '') +
      '<div class="um-meta">' +
      'Login: <b>' + (isMicrosoft(user.auth_provider) ? 'Microsoft Entra ID' : 'e-mail e senha') + '</b><br>' +
      'Último acesso: <b>' + esc(fmtDate(user.last_login)) + '</b><br>' +
      'Conta criada em: <b>' + esc(fmtDate(user.created_at)) + '</b><br>' +
      'Entra ID: <b>' + (user.in_entra ? (user.entra_enabled === false ? 'presente, conta desativada' : 'presente e ativa') : 'não encontrado na última sincronização') + '</b><br>' +
      'Sincronizado em: <b>' + esc(fmtDate(user.entra_synced_at)) + '</b><br>' +
      'ID interno: <code>' + esc(user.id) + '</code>' +
      '</div></div>';

    document.body.appendChild(root);
    root.onclick = function (event) { if (event.target === root) closeDrawer(); };
    $('#um-drawer-close', root).onclick = closeDrawer;
    var cancel = $('#um-d-cancel', root);
    if (cancel) cancel.onclick = closeDrawer;
    var save = $('#um-d-save', root);
    if (save) save.onclick = function () { saveDrawer(user, this); };
  }

  function closeDrawer() {
    var node = document.getElementById('um-drawer');
    if (node) node.remove();
  }

  async function saveDrawer(user, button) {
    var root = document.getElementById('um-drawer');
    if (!root) return;
    button.disabled = true;
    button.textContent = 'Salvando…';
    try {
      var role = $('#um-d-role', root).value;
      var status = $('#um-d-status', root).value;

      // Perfil primeiro (RPC legada mexe em active), situação detalhada depois.
      if (role !== user.role_code) {
        await rpc('admin_set_user_access', { p_user_id: user.id, p_role_code: role, p_active: status === 'ativo' });
      }
      await rpc('admin_update_user_profile', {
        p_user_id: user.id,
        p_patch: {
          name: $('#um-d-name', root).value.trim(),
          job_title: $('#um-d-job', root).value.trim(),
          employee_id: $('#um-d-emp', root).value.trim(),
          department: $('#um-d-dep', root).value.trim(),
          sector: $('#um-d-dep', root).value.trim(),
          phone: $('#um-d-phone', root).value.trim(),
          manager_email: $('#um-d-manager', root).value.trim(),
          access_status: status,
          status_reason: $('#um-d-reason', root).value.trim()
        }
      });
      var selected = $$('[data-um-d-group]', root).filter(function (i) { return i.checked; })
        .map(function (i) { return i.getAttribute('data-um-d-group'); });
      await rpc('admin_set_user_groups', { p_user_id: user.id, p_group_codes: selected });

      closeDrawer();
      toast('Usuário atualizado e registrado na auditoria.');
      await loadDirectory();
    } catch (e) {
      button.disabled = false;
      button.textContent = 'Salvar alterações';
      toast(e.message || 'Não foi possível salvar.', 'err');
    }
  }

  // ================================================================== ações
  async function saveRow(userId, button) {
    var pending = S.pending[userId];
    if (!pending) return;
    var user = ((S.data && S.data.rows) || []).filter(function (u) { return u.id === userId; })[0] || {};
    button.disabled = true;
    button.textContent = '…';
    try {
      var role = pending.role_code || user.role_code;
      var status = pending.access_status || user.access_status;
      if (role !== user.role_code) {
        await rpc('admin_set_user_access', { p_user_id: userId, p_role_code: role, p_active: status === 'ativo' });
      }
      if (status !== user.access_status) {
        await rpc('admin_update_user_profile', { p_user_id: userId, p_patch: { access_status: status } });
      }
      delete S.pending[userId];
      toast('Acesso de ' + (user.name || 'usuário') + ' atualizado.');
      await loadDirectory();
    } catch (e) {
      button.disabled = false;
      button.textContent = 'Salvar';
      toast(e.message || 'Não foi possível salvar.', 'err');
    }
  }

  async function syncEntra(button) {
    var label = button.textContent;
    button.disabled = true;
    button.textContent = 'Sincronizando…';
    try {
      var result = await callApi('/admin/entra/sync', { method: 'POST', body: JSON.stringify({ apply: true }) });
      var data = result && result.data ? result.data : {};
      toast('Entra ID sincronizado: ' + (data.users_fetched || 0) + ' contas, ' +
        (data.profiles_updated || 0) + ' perfis atualizados, ' + (data.managers_linked || 0) + ' gestores vinculados.');
      await loadDirectory();
    } catch (e) {
      toast(e.message || 'Falha ao sincronizar com o Entra ID.', 'err');
    } finally {
      button.disabled = false;
      button.textContent = label;
    }
  }

  function exportCsv() {
    var rows = (S.data && S.data.rows) || [];
    if (!rows.length) return toast('Nada para exportar com estes filtros.', 'err');
    var head = ['Nome', 'E-mail', 'Login', 'Cargo', 'Setor', 'Matricula', 'Perfil', 'Situacao', 'Grupos', 'Gestor', 'Ultimo acesso'];
    var lines = [head.join(';')].concat(rows.map(function (u) {
      return [
        u.name || '', u.email || '', isMicrosoft(u.auth_provider) ? 'Microsoft' : 'Senha',
        u.job_title || '', u.department || u.sector || '', u.employee_id || '',
        u.role_name || u.role_code || '', statusLabel(u.access_status),
        (u.groups || []).map(function (g) { return g.name; }).join(' | '),
        u.manager_name || u.manager_email || '', u.last_login ? fmtDay(u.last_login) : ''
      ].map(function (v) { return '"' + String(v).replace(/"/g, '""') + '"'; }).join(';');
    }));
    var blob = new Blob(['﻿' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
    var url = URL.createObjectURL(blob);
    var link = document.createElement('a');
    link.href = url;
    link.download = 'biotrop-usuarios-' + new Date().toISOString().slice(0, 10) + '.csv';
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 1500);
  }

  // ================================================================= eventos
  function bindDirectory(root) {
    var search = $('#um-search', root);
    if (search) {
      search.oninput = function () {
        var value = this.value;
        clearTimeout(S.searchTimer);
        S.searchTimer = setTimeout(function () {
          S.filters.search = value.trim();
          S.offset = 0;
          loadDirectory();
        }, 420);
      };
    }
    [['#um-filter-role', 'role'], ['#um-filter-status', 'status'], ['#um-filter-group', 'group'], ['#um-filter-dep', 'department']]
      .forEach(function (pair) {
        var node = $(pair[0], root);
        if (node) node.onchange = function () { S.filters[pair[1]] = this.value; S.offset = 0; loadDirectory(); };
      });

    var reload = $('#um-reload', root);
    if (reload) reload.onclick = function () { loadDirectory(); };
    var sync = $('#um-sync', root);
    if (sync) sync.onclick = function () { syncEntra(this); };
    var exportBtn = $('#um-export', root);
    if (exportBtn) exportBtn.onclick = exportCsv;
    var prev = $('#um-prev', root);
    if (prev) prev.onclick = function () { S.offset = Math.max(0, S.offset - S.limit); loadDirectory(); };
    var next = $('#um-next', root);
    if (next) next.onclick = function () { S.offset = S.offset + S.limit; loadDirectory(); };

    $$('[data-um-role]', root).forEach(function (select) {
      select.onchange = function () {
        var id = this.getAttribute('data-um-role');
        S.pending[id] = S.pending[id] || {};
        S.pending[id].role_code = this.value;
        renderActive();
      };
    });
    $$('[data-um-status]', root).forEach(function (select) {
      select.onchange = function () {
        var id = this.getAttribute('data-um-status');
        S.pending[id] = S.pending[id] || {};
        S.pending[id].access_status = this.value;
        renderActive();
      };
    });
    $$('[data-um-save]', root).forEach(function (button) {
      button.onclick = function () { saveRow(this.getAttribute('data-um-save'), this); };
    });
    $$('[data-um-open]', root).forEach(function (button) {
      button.onclick = function () { openDrawer(this.getAttribute('data-um-open')); };
    });
  }

  function bindGroups(root) {
    var save = $('#um-group-save', root);
    if (save) {
      save.onclick = async function () {
        var code = $('#um-group-code', root).value.trim();
        var name = $('#um-group-name', root).value.trim();
        if (!code || !name) return toast('Informe código e nome do grupo.', 'err');
        this.disabled = true;
        try {
          await rpc('admin_upsert_access_group', {
            p_code: code,
            p_name: name,
            p_description: $('#um-group-desc', root).value.trim() || null,
            p_kind: $('#um-group-kind', root).value,
            p_active: true
          });
          toast('Grupo salvo.');
          await loadDirectory();
        } catch (e) {
          toast(e.message || 'Não foi possível salvar o grupo.', 'err');
        } finally {
          this.disabled = false;
        }
      };
    }
    $$('[data-um-group-edit]', root).forEach(function (button) {
      button.onclick = function () {
        var code = this.getAttribute('data-um-group-edit');
        var group = ((S.data && S.data.groups) || []).filter(function (g) { return g.code === code; })[0];
        if (!group) return;
        $('#um-group-code', root).value = group.code;
        $('#um-group-name', root).value = group.name;
        $('#um-group-kind', root).value = group.kind;
        $('#um-group-desc', root).value = group.description || '';
        $('#um-group-name', root).focus();
      };
    });
    $$('[data-um-group-filter]', root).forEach(function (button) {
      button.onclick = function () {
        S.filters.group = this.getAttribute('data-um-group-filter');
        S.offset = 0;
        setTab('directory');
      };
    });
  }

  function bindExceptions(root) {
    var save = $('#um-exc-save', root);
    if (save) {
      save.onclick = async function () {
        var email = $('#um-exc-email', root).value.trim().toLowerCase();
        if (!email || email.indexOf('@') < 1) return toast('Informe um e-mail válido.', 'err');
        var expires = $('#um-exc-expires', root).value;
        this.disabled = true;
        try {
          await rpc('admin_upsert_login_exception', {
            p_email: email,
            p_display_name: $('#um-exc-name', root).value.trim() || null,
            p_allow_password_login: $('#um-exc-password', root).checked,
            p_note: $('#um-exc-note', root).value.trim() || null,
            p_expires_at: expires ? new Date(expires + 'T23:59:59').toISOString() : null,
            p_enabled: true
          });
          toast('Exceção cadastrada.');
          await loadExceptions();
        } catch (e) {
          toast(e.message || 'Não foi possível cadastrar.', 'err');
        } finally {
          this.disabled = false;
        }
      };
    }
    $$('[data-um-exc-toggle]', root).forEach(function (button) {
      button.onclick = async function () {
        var email = this.getAttribute('data-um-exc-toggle');
        var enabled = this.getAttribute('data-enabled') === '1';
        var row = (S.exceptions || []).filter(function (e) { return e.email === email; })[0] || {};
        this.disabled = true;
        try {
          await rpc('admin_upsert_login_exception', {
            p_email: email,
            p_display_name: row.display_name || null,
            p_allow_password_login: !!row.allow_password_login,
            p_note: row.note || null,
            p_expires_at: row.expires_at || null,
            p_enabled: !enabled
          });
          await loadExceptions();
        } catch (e) {
          toast(e.message || 'Falha ao alterar.', 'err');
          this.disabled = false;
        }
      };
    });
    $$('[data-um-exc-del]', root).forEach(function (button) {
      button.onclick = async function () {
        var email = this.getAttribute('data-um-exc-del');
        if (!window.confirm('Remover a exceção de ' + email + '? A pessoa passará a depender do login Microsoft.')) return;
        this.disabled = true;
        try {
          await rpc('admin_delete_login_exception', { p_email: email });
          toast('Exceção removida.');
          await loadExceptions();
        } catch (e) {
          toast(e.message || 'Falha ao remover.', 'err');
          this.disabled = false;
        }
      };
    });
  }

  function bindPolicy(root) {
    var save = $('#um-pol-save', root);
    if (!save) return;
    save.onclick = async function () {
      this.disabled = true;
      try {
        await rpc('admin_update_access_settings', {
          p_patch: {
            password_login_mode: $('#um-pol-mode', root).value,
            default_role_code: $('#um-pol-role', root).value,
            auto_provision: $('#um-pol-provision', root).checked,
            auto_activate: $('#um-pol-activate', root).checked,
            entra_tenant_id: $('#um-pol-tenant', root).value.trim()
          }
        });
        toast('Política de acesso atualizada.');
        await loadDirectory();
      } catch (e) {
        toast(e.message || 'Não foi possível salvar a política.', 'err');
      } finally {
        this.disabled = false;
      }
    };
  }

  // ============================================================== integração
  function renderActive() {
    var root = document.getElementById('um-root');
    if (!root || !S.tab) return;
    var html = '';
    if (S.tab === 'directory') html = renderDirectory();
    else if (S.tab === 'groups') html = renderGroups();
    else if (S.tab === 'exceptions') html = renderExceptions();
    else if (S.tab === 'policy') html = renderPolicy();
    else if (S.tab === 'audit') html = renderAudit();
    root.innerHTML = html;

    if (S.tab === 'directory') bindDirectory(root);
    else if (S.tab === 'groups') bindGroups(root);
    else if (S.tab === 'exceptions') bindExceptions(root);
    else if (S.tab === 'policy') bindPolicy(root);

    var retry = $('#um-reload', root);
    if (retry && !retry.onclick) retry.onclick = function () { loadDirectory(); };
  }

  function setTab(tab) {
    S.tab = tab;
    var legacy = document.getElementById('admin-tab-content');
    var root = document.getElementById('um-root');
    if (legacy) legacy.style.display = tab ? 'none' : '';
    if (root) root.style.display = tab ? '' : 'none';
    $$('[data-umtab]').forEach(function (button) {
      button.classList.toggle('active', button.getAttribute('data-umtab') === tab);
    });
    if (tab) $$('[data-admintab]').forEach(function (button) { button.classList.remove('active'); });
    if (!tab) return;

    if (tab === 'exceptions' && !S.exceptions) { loadExceptions(); return; }
    if (tab === 'audit' && !S.audit) { loadAudit(); return; }
    if (!S.data) { loadDirectory(); return; }
    renderActive();
  }

  function mount() {
    var legacy = document.getElementById('admin-tab-content');
    var tabsRow = legacy ? legacy.parentNode.querySelector('.tabs-row') : null;
    if (!legacy || !tabsRow) return;

    if (!tabsRow.dataset.umReady) {
      tabsRow.dataset.umReady = '1';
      // A aba legada de usuários é substituída pelo diretório completo.
      var legacyUsers = tabsRow.querySelector('[data-admintab="users"]');
      if (legacyUsers) legacyUsers.style.display = 'none';

      var fragment = document.createDocumentFragment();
      TABS.forEach(function (tab) {
        var button = document.createElement('button');
        button.className = 'tab-btn';
        button.type = 'button';
        button.setAttribute('data-umtab', tab.id);
        button.textContent = tab.label;
        button.onclick = function () { setTab(tab.id); };
        fragment.appendChild(button);
      });
      tabsRow.insertBefore(fragment, tabsRow.firstChild);

      $$('[data-admintab]', tabsRow).forEach(function (button) {
        button.addEventListener('click', function () { setTab(null); });
      });
    }

    var created = false;
    if (!document.getElementById('um-root')) {
      var root = document.createElement('div');
      root.id = 'um-root';
      root.className = 'um-root';
      root.style.display = 'none';
      legacy.parentNode.insertBefore(root, legacy.nextSibling);
      created = true;
    }

    // Entrando na administração, o diretório completo é a visão padrão.
    // Só reagimos quando o container foi (re)criado: assim o MutationObserver
    // não entra em laço com o próprio innerHTML deste módulo.
    if (created || !S.tab) setTab(S.tab || 'directory');
  }

  function boot() {
    ensureStyle();
    mount();
    new MutationObserver(function () {
      if (document.getElementById('admin-tab-content')) mount();
      else { S.tab = null; }
    }).observe(document.body, { childList: true, subtree: true });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, { once: true });
  else boot();
})();
