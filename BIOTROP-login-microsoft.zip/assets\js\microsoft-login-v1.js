/* BIOTROP — Login Microsoft (Entra ID) restrito ao domínio corporativo.
   Política real (domínio autorizado, modo de senha, exceções) vem do banco:
   corporate_login_policy() e guard_corporate_session(). O navegador apenas obedece. */
(function () {
  'use strict';
  if (window.__BIOTROP_MS_LOGIN_V1) return;
  window.__BIOTROP_MS_LOGIN_V1 = true;

  var STYLE_ID = 'biotrop-ms-login-v1';
  var POLICY_CACHE = {};
  var policy = { microsoft_enabled: true, password_login_mode: 'exceptions', primary_domain: 'biotrop.com.br' };
  var guarding = false;
  var lastDeniedMessage = '';

  function sb() { return window.SB || null; }
  function esc(v) {
    return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  function injectStyle() {
    if (document.getElementById(STYLE_ID)) return;
    var s = document.createElement('style');
    s.id = STYLE_ID;
    s.textContent = [
      '.ms-login-zone{margin:4px 0 18px}',
      '.ms-login-btn{width:100%;display:flex;align-items:center;justify-content:center;gap:10px;padding:13px 16px;border:1px solid #d7e6df;border-radius:12px;background:#fff;color:#17332b;font-size:14px;font-weight:800;cursor:pointer;transition:box-shadow .18s ease,transform .18s ease,border-color .18s ease}',
      '.ms-login-btn:hover{border-color:#54b99b;box-shadow:0 8px 22px rgba(8,124,103,.14);transform:translateY(-1px)}',
      '.ms-login-btn:disabled{opacity:.6;cursor:progress;transform:none}',
      '.ms-login-btn svg{flex:0 0 18px}',
      '.ms-login-hint{margin:10px 2px 0;font-size:11.5px;line-height:1.5;color:#6f807b}',
      '.ms-login-hint b{color:#17332b}',
      '.ms-login-sep{display:flex;align-items:center;gap:10px;margin:18px 0 6px;color:#8fa19b;font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.08em}',
      '.ms-login-sep:before,.ms-login-sep:after{content:"";flex:1;height:1px;background:#e1ebe8}',
      '.ms-exception-link{background:none;border:0;padding:6px 0;color:#087c67;font-size:12px;font-weight:800;cursor:pointer;text-decoration:underline}',
      '.ms-policy-box{margin-top:10px;padding:11px 12px;border-radius:11px;font-size:12px;line-height:1.5}',
      '.ms-policy-warn{background:#fff6e6;color:#8a5a00;border:1px solid #f3dfb8}',
      '.ms-policy-error{background:#fdecec;color:#a62922;border:1px solid #f3c9c5}',
      '.ms-policy-ok{background:#eef8f3;color:#176449;border:1px solid #cfe9de}',
      '.ms-blocked-overlay{position:fixed;inset:0;z-index:999998;background:rgba(0,35,38,.72);display:flex;align-items:center;justify-content:center;padding:22px;font-family:Inter,system-ui,sans-serif}',
      '.ms-blocked-card{width:100%;max-width:470px;background:#fff;border-radius:22px;padding:30px;box-shadow:0 30px 90px rgba(0,0,0,.3);text-align:center}',
      '.ms-blocked-card h2{margin:0 0 10px;color:#003c41;font-size:21px;letter-spacing:-.4px}',
      '.ms-blocked-card p{margin:0 0 8px;color:#60746d;font-size:13px;line-height:1.6}',
      '.ms-blocked-card .ms-blocked-mail{display:block;margin:14px 0;padding:10px;border-radius:10px;background:#f4f8f6;color:#17332b;font-size:12px;font-weight:800;word-break:break-all}',
      '.ms-blocked-card button{margin-top:12px;width:100%;border:0;border-radius:999px;background:#003c41;color:#fff;padding:13px;font-weight:800;font-size:13px;cursor:pointer}',
      '.ms-blocked-icon{width:52px;height:52px;margin:0 auto 16px;border-radius:16px;display:grid;place-items:center;background:#fff6e6;font-size:24px}'
    ].join('\n');
    document.head.appendChild(s);
  }

  function msLogo() {
    return '<svg width="18" height="18" viewBox="0 0 23 23" aria-hidden="true">' +
      '<rect x="1" y="1" width="10" height="10" fill="#f25022"/>' +
      '<rect x="12" y="1" width="10" height="10" fill="#7fba00"/>' +
      '<rect x="1" y="12" width="10" height="10" fill="#00a4ef"/>' +
      '<rect x="12" y="12" width="10" height="10" fill="#ffb900"/></svg>';
  }

  // ---------------------------------------------------------------- política
  async function loadPolicy(email) {
    var client = sb();
    if (!client) return policy;
    var key = (email || '').toLowerCase();
    if (POLICY_CACHE[key]) return POLICY_CACHE[key];
    try {
      var r = await client.rpc('corporate_login_policy', { p_email: email || null });
      if (r.error) throw r.error;
      var data = r.data || {};
      POLICY_CACHE[key] = data;
      if (!key) policy = data;
      return data;
    } catch (e) {
      console.warn('[BIOTROP] Política de login indisponível:', e.message || e);
      // Sem política o navegador não inventa permissão: mantém o padrão restritivo.
      return key ? { password_allowed: false, unavailable: true } : policy;
    }
  }

  // ------------------------------------------------------------------ login
  async function signInWithMicrosoft(button) {
    var client = sb();
    var box = document.getElementById('login-error-box');
    if (!client) {
      if (box) box.innerHTML = '<div class="login-error">Supabase não configurado. Revise config.js.</div>';
      return;
    }
    if (button) { button.disabled = true; button.dataset.label = button.innerHTML; button.innerHTML = msLogo() + '<span>Abrindo a Microsoft…</span>'; }
    try {
      var redirectTo = window.location.origin + window.location.pathname;
      var queryParams = { prompt: 'select_account' };
      if (policy && policy.primary_domain) queryParams.domain_hint = policy.primary_domain;
      var r = await client.auth.signInWithOAuth({
        provider: 'azure',
        options: {
          scopes: 'openid profile email offline_access User.Read',
          redirectTo: redirectTo,
          queryParams: queryParams
        }
      });
      if (r.error) throw r.error;
    } catch (e) {
      if (button) { button.disabled = false; if (button.dataset.label) button.innerHTML = button.dataset.label; }
      if (box) {
        box.innerHTML = '<div class="login-error">' + esc(
          /provider is not enabled/i.test(e.message || '')
            ? 'O login Microsoft ainda não foi habilitado no Supabase (Authentication → Providers → Azure). Fale com a TI.'
            : (e.message || 'Não foi possível iniciar o login Microsoft.')
        ) + '</div>';
      }
    }
  }

  // ------------------------------------------------------- tela de login
  function fieldNodes(form, inputSelector) {
    var nodes = [];
    var input = form.querySelector(inputSelector);
    if (!input) return nodes;
    var wrap = input.closest('.input-wrap');
    if (wrap) {
      nodes.push(wrap);
      var label = wrap.previousElementSibling;
      if (label && label.classList.contains('field-label')) nodes.push(label);
    }
    return nodes;
  }

  function emailNodes(form) {
    return fieldNodes(form, '#login-usuario');
  }

  function passwordNodes(form) {
    var nodes = fieldNodes(form, '#login-senha');
    ['.row-between', '.submit-btn', '#register-access-btn'].forEach(function (selector) {
      var node = form.querySelector(selector);
      if (node) nodes.push(node);
    });
    return nodes;
  }

  function setVisible(nodes, visible) {
    nodes.forEach(function (node) { node.style.display = visible ? '' : 'none'; });
  }

  function setPasswordVisible(form, visible) {
    setVisible(passwordNodes(form), visible);
    var senha = form.querySelector('#login-senha');
    if (senha && !visible) senha.value = '';
  }

  async function checkExceptionFlow(form, statusBox) {
    var input = form.querySelector('#login-usuario');
    var email = ((input && input.value) || '').trim().toLowerCase();
    if (!email || email.indexOf('@') < 1) {
      statusBox.className = 'ms-policy-box ms-policy-warn';
      statusBox.innerHTML = 'Digite seu e-mail corporativo acima para verificarmos a liberação.';
      statusBox.style.display = '';
      if (input) input.focus();
      return;
    }
    statusBox.className = 'ms-policy-box ms-policy-warn';
    statusBox.innerHTML = 'Verificando liberação…';
    statusBox.style.display = '';

    var result = await loadPolicy(email);
    if (result.access_allowed === false) {
      statusBox.className = 'ms-policy-box ms-policy-error';
      statusBox.innerHTML = 'Este e-mail não pertence ao domínio corporativo autorizado. Use sua conta <b>@' +
        esc(policy.primary_domain || 'biotrop.com.br') + '</b>.';
      setPasswordVisible(form, false);
      return;
    }
    if (result.password_allowed) {
      statusBox.className = 'ms-policy-box ms-policy-ok';
      statusBox.innerHTML = 'Acesso por senha liberado para este e-mail. Informe sua senha abaixo.';
      setPasswordVisible(form, true);
      var senha = form.querySelector('#login-senha');
      if (senha) senha.focus();
      return;
    }
    statusBox.className = 'ms-policy-box ms-policy-error';
    statusBox.innerHTML = result.unavailable
      ? 'Não foi possível verificar a liberação agora. Tente o login Microsoft ou fale com a TI.'
      : 'Este e-mail não tem exceção de senha cadastrada. Entre com <b>sua conta Microsoft Biotrop</b> ou solicite uma exceção ao administrador.';
    setPasswordVisible(form, false);
  }

  function enhanceLoginScreen() {
    var form = document.getElementById('login-form');
    if (!form || form.dataset.msLoginReady === '1') return;
    form.dataset.msLoginReady = '1';

    // Bloco principal: o caminho normal é a conta Microsoft.
    var zone = document.createElement('div');
    zone.className = 'ms-login-zone';
    zone.innerHTML =
      '<button type="button" class="ms-login-btn" id="ms-login-btn">' + msLogo() +
      '<span>Entrar com a conta Microsoft Biotrop</span></button>' +
      '<p class="ms-login-hint">Use o mesmo login do <b>Outlook e Teams</b>. Somente contas <b>@' +
      esc(policy.primary_domain || 'biotrop.com.br') + '</b> têm acesso.</p>';
    form.parentNode.insertBefore(zone, form);

    // Fluxo de exceção fica no fim do formulário, só aparece quando pedido.
    var exceptionZone = document.createElement('div');
    exceptionZone.className = 'ms-login-zone';
    exceptionZone.innerHTML =
      '<div class="ms-login-sep">acesso excepcional</div>' +
      '<button type="button" class="ms-exception-link" id="ms-exception-link">Entrar com e-mail e senha (exceção autorizada)</button>' +
      '<button type="button" class="ms-login-btn" id="ms-exception-check" style="display:none;margin-top:10px">' +
      '<span>Verificar liberação deste e-mail</span></button>' +
      '<div class="ms-policy-box" id="ms-policy-box" style="display:none"></div>';
    form.appendChild(exceptionZone);

    setVisible(emailNodes(form), false);
    setPasswordVisible(form, false);

    // O separador "ou" do layout antigo separava senha de nada; sai de cena.
    var divider = form.parentNode.querySelector('.divider');
    if (divider) divider.style.display = 'none';

    var statusBox = exceptionZone.querySelector('#ms-policy-box');
    var link = exceptionZone.querySelector('#ms-exception-link');
    var check = exceptionZone.querySelector('#ms-exception-check');

    zone.querySelector('#ms-login-btn').onclick = function () { signInWithMicrosoft(this); };
    link.onclick = function () {
      setVisible(emailNodes(form), true);
      link.style.display = 'none';
      check.style.display = '';
      statusBox.className = 'ms-policy-box ms-policy-warn';
      statusBox.innerHTML = 'O acesso por senha é liberado caso a caso. Informe seu e-mail corporativo para verificarmos.';
      statusBox.style.display = '';
      var input = form.querySelector('#login-usuario');
      if (input) input.focus();
    };
    check.onclick = function () { checkExceptionFlow(form, statusBox); };

    // Se o usuário digitar outro e-mail, a liberação precisa ser reavaliada.
    var emailInput = form.querySelector('#login-usuario');
    if (emailInput) {
      emailInput.addEventListener('change', function () {
        var senha = form.querySelector('#login-senha');
        if (senha && senha.closest('.input-wrap') && senha.closest('.input-wrap').style.display !== 'none') {
          setPasswordVisible(form, false);
          statusBox.className = 'ms-policy-box ms-policy-warn';
          statusBox.innerHTML = 'E-mail alterado. Verifique a liberação novamente.';
        }
      });
    }

    if (lastDeniedMessage) {
      var box = document.getElementById('login-error-box');
      if (box) box.innerHTML = '<div class="login-error">' + esc(lastDeniedMessage) + '</div>';
      lastDeniedMessage = '';
    }

    reportOauthError();
  }

  function reportOauthError() {
    var hash = new URLSearchParams((location.hash || '').replace(/^#/, ''));
    var query = new URLSearchParams(location.search || '');
    var error = hash.get('error') || query.get('error');
    if (!error) return;
    var description = hash.get('error_description') || query.get('error_description') || '';
    var box = document.getElementById('login-error-box');
    var friendly = /access_denied|consent/i.test(error + description)
      ? 'A Microsoft recusou o acesso desta conta. Confirme com a TI se você está autorizado no aplicativo corporativo.'
      : (decodeURIComponent(description).replace(/\+/g, ' ') || 'Falha no retorno do login Microsoft.');
    if (box) box.innerHTML = '<div class="login-error">' + esc(friendly) + '</div>';
    history.replaceState({}, document.title, location.pathname);
  }

  // ------------------------------------------------- guarda de sessão
  function showBlocked(result) {
    var existing = document.getElementById('ms-blocked-overlay');
    if (existing) existing.remove();
    var root = document.createElement('div');
    root.id = 'ms-blocked-overlay';
    root.className = 'ms-blocked-overlay';
    var pending = String(result.reason || '').indexOf('profile_inativo') === 0;
    root.innerHTML =
      '<div class="ms-blocked-card">' +
      '<div class="ms-blocked-icon">' + (pending ? '⏳' : '🔒') + '</div>' +
      '<h2>' + (pending ? 'Conta criada — aguardando liberação' : 'Acesso não autorizado') + '</h2>' +
      '<p>' + esc(result.message || 'Fale com o administrador do sistema.') + '</p>' +
      (result.email ? '<span class="ms-blocked-mail">' + esc(result.email) + '</span>' : '') +
      '<p>Se você acabou de entrar pela primeira vez, o administrador da manutenção precisa atribuir seu perfil de acesso.</p>' +
      '<button type="button" id="ms-blocked-out">Sair e voltar ao login</button>' +
      '</div>';
    document.body.appendChild(root);
    root.querySelector('#ms-blocked-out').onclick = async function () {
      this.disabled = true;
      try { await sb().auth.signOut(); } catch (e) { /* segue para o login */ }
      location.replace(location.pathname);
    };
  }

  async function runGuard() {
    var client = sb();
    if (!client || guarding) return true;
    guarding = true;
    try {
      var session = await client.auth.getSession();
      if (!session || !session.data || !session.data.session) return true;
      var r = await client.rpc('guard_corporate_session');
      if (r.error) {
        // Banco sem a migração aplicada: não trava o sistema, apenas avisa.
        if (/does not exist|not find|schema cache/i.test(r.error.message || '')) {
          console.warn('[BIOTROP] guard_corporate_session ausente. Aplique database/migrations/2026-09-microsoft-entra-access.sql');
          return true;
        }
        throw r.error;
      }
      var result = r.data || {};
      if (result.allowed) return true;

      result.email = result.email || (session.data.session.user && session.data.session.user.email);
      lastDeniedMessage = result.message || 'Acesso não autorizado.';
      showBlocked(result);
      try { await client.auth.signOut(); } catch (e) { /* overlay já informou o usuário */ }
      return false;
    } catch (e) {
      console.warn('[BIOTROP] Falha na guarda de sessão:', e.message || e);
      return true;
    } finally {
      guarding = false;
    }
  }

  function patchEnterAuthenticated() {
    if (typeof window.enterAuthenticated !== 'function' || window.enterAuthenticated.__msGuard) return;
    var original = window.enterAuthenticated;
    var wrapped = async function (session) {
      var ok = await runGuard();
      if (!ok) return null;
      return original.apply(this, arguments);
    };
    wrapped.__msGuard = true;
    window.enterAuthenticated = wrapped;
  }

  // ------------------------------------------------------------------ boot
  function boot() {
    injectStyle();
    loadPolicy('').then(function () {
      var hint = document.querySelector('.ms-login-hint b:last-child');
      if (hint && policy.primary_domain) hint.textContent = '@' + policy.primary_domain;
    });

    patchEnterAuthenticated();
    enhanceLoginScreen();

    // A guarda também roda por conta própria: se o patch não chegou antes do
    // boot do shell legado, a sessão inválida é derrubada em seguida.
    runGuard();

    var client = sb();
    if (client && !client.__msGuardHooked) {
      client.__msGuardHooked = true;
      client.auth.onAuthStateChange(function (event) {
        if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') runGuard();
        if (event === 'SIGNED_OUT') setTimeout(enhanceLoginScreen, 60);
      });
    }

    new MutationObserver(function () {
      patchEnterAuthenticated();
      enhanceLoginScreen();
    }).observe(document.body, { childList: true, subtree: true });
  }

  // Patch imediato: o shell legado registra o próprio DOMContentLoaded antes deste
  // módulo, então a guarda precisa envolver enterAuthenticated já na carga do script.
  patchEnterAuthenticated();

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, { once: true });
  else boot();
})();
