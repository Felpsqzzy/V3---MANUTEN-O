# BIOTROP — Login Microsoft (Entra ID) e gestão de usuários

Este documento é o roteiro de implantação do acesso corporativo: **somente contas
`@biotrop.com.br` entram na plataforma**, o perfil é criado automaticamente no primeiro
login e a administração de usuários passa a ter diretório, grupos, exceções, política e
auditoria.

Público: TI / Infraestrutura (passos 1 a 4) e administrador da Manutenção (passos 5 e 6).

---

## 1. Como o acesso funciona

```text
Colaborador abre o site
        |
        v
"Entrar com a conta Microsoft Biotrop"
        |
        v
Microsoft Entra ID autentica (mesmo login do Outlook/Teams)
        |
        v
Supabase Auth cria a sessão
        |
        v
Banco valida o domínio e o provedor  <-- trava obrigatória
        |
        +-- e-mail fora de @biotrop.com.br .......... acesso recusado
        +-- conta de senha sem exceção autorizada ... acesso recusado
        |
        v
Perfil criado/atualizado com cargo, setor, matrícula e gestor
        |
        v
Sistema aberto conforme o perfil de acesso
```

A validação **não** está no navegador. Ela vive em duas funções do banco:

| Função | Onde age | O que garante |
| --- | --- | --- |
| `handle_new_auth_user_biotrop_v3()` | trigger em `auth.users` | Nenhuma conta fora do domínio autorizado chega a existir |
| `guard_corporate_session()` | a cada entrada no sistema | Sessão de conta bloqueada, desligada ou fora do domínio é derrubada |

Consequência prática: mesmo que alguém chame a API direto, ou que o front seja
alterado, a regra continua valendo.

---

## 2. App Registration no Azure (TI)

No portal do Azure → **Microsoft Entra ID** → **App registrations** → **New registration**:

| Campo | Valor |
| --- | --- |
| Name | `BIOTROP - Plataforma de Manutenção` |
| Supported account types | **Accounts in this organizational directory only (Single tenant)** |
| Redirect URI | Web → `https://<PROJETO>.supabase.co/auth/v1/callback` |

> O **Single tenant** é a primeira barreira: contas de outros tenants nem chegam à
> tela de consentimento. A trava de domínio no banco é a segunda, e cobre o caso de
> convidados (guests) do próprio tenant com e-mail externo.

Depois do registro, anote:

- **Application (client) ID**
- **Directory (tenant) ID**
- **Client secret** — em *Certificates & secrets* → *New client secret*
  (guarde a validade; a renovação precisa entrar no calendário da TI)

### Permissões

Em **API permissions**:

| Permissão | Tipo | Para quê | Consentimento |
| --- | --- | --- | --- |
| `openid`, `profile`, `email`, `User.Read` | Delegada | Login do colaborador | usuário |
| `User.Read.All` | **Aplicativo** | Sincronizar cargo, setor, matrícula e **gestor** | **admin** |
| `Mail.Send` | Aplicativo | E-mails automáticos (já usado hoje) | admin |

Sem `User.Read.All` o login funciona, mas o vínculo **colaborador → gestor** e a
matrícula precisam ser preenchidos à mão. É esse vínculo que o painel do gestor de
treinamentos usa.

---

## 3. Provider Azure no Supabase (TI)

Supabase → **Authentication** → **Providers** → **Azure**:

| Campo | Valor |
| --- | --- |
| Enable Sign in with Azure | ligado |
| Application (client) ID | client ID do passo 2 |
| Secret Value | client secret do passo 2 |
| Azure Tenant URL | `https://login.microsoftonline.com/<TENANT_ID>` |

Preencher o **Azure Tenant URL** é obrigatório: sem ele o Supabase usa o endpoint
`common`, que aceita qualquer tenant Microsoft.

Em **Authentication → URL Configuration**, inclua em *Redirect URLs* os endereços do
site (produção e pré-produção), por exemplo:

```text
https://manutencao.biotrop.com.br/app.html
https://<projeto>.vercel.app/app.html
http://localhost:3000/app.html
```

---

## 4. Banco e variáveis de ambiente

### 4.1 Migração

Aplique, no SQL Editor do Supabase (ou via psql), na ordem:

```text
database/BIOTROP_INSTALACAO_V2.sql          (se ainda não aplicado)
database/migrations/2026-09-corporate-access.sql
database/migrations/2026-09-microsoft-entra-access.sql
```

A migração é idempotente e não apaga dados. Ela cria:

- `corporate_access_settings` — política de acesso (modo de senha, provisionamento)
- `corporate_allowed_domains` — domínios autorizados (já vem com `biotrop.com.br`)
- `access_groups` / `access_group_members` — grupos por função e setor
- `entra_directory` / `entra_sync_runs` — diretório sincronizado e histórico
- campos novos em `profiles` — `azure_oid`, `job_title`, `employee_id`, `manager_id`,
  `access_status`, `auth_provider`, entre outros
- as RPCs de administração, todas com verificação de permissão e auditoria

### 4.2 Registre o tenant

```sql
select public.admin_update_access_settings('{"entra_tenant_id":"<TENANT_ID>"}'::jsonb);
```

### 4.3 Variáveis do servidor (Vercel / VM)

```bash
SUPABASE_URL=https://<projeto>.supabase.co
SUPABASE_ANON_KEY=...
SUPABASE_SERVICE_ROLE_KEY=...        # nunca no frontend
CORS_ORIGINS=https://manutencao.biotrop.com.br

MS_TENANT_ID=<TENANT_ID>
MS_CLIENT_ID=<CLIENT_ID>
MS_CLIENT_SECRET=<CLIENT_SECRET>
GRAPH_SENDER_EMAIL=manutencao@biotrop.com.br
```

As três variáveis `MS_*` são as mesmas já usadas pelo envio de e-mail via Graph.

---

## 5. Primeiro acesso do administrador

1. Entre no site e clique em **Entrar com a conta Microsoft Biotrop**.
2. Na primeira entrada o perfil é criado automaticamente. Se `auto_activate` estiver
   ligado (padrão), você já entra com o perfil padrão `viewer`.
3. Promova sua conta a super administrador:

```sql
select public.bootstrap_biotrop_super_admin('felipe.vieira@biotrop.com.br');
```

4. Recarregue o site. O menu **Administração** passa a mostrar as abas novas.
5. Em **Administração → Diretório de usuários**, clique em **Sincronizar Entra ID**.
   Cargo, setor, matrícula, telefone e gestor de todos os colaboradores são preenchidos.

---

## 6. A tela de gestão de usuários

**Administração → Diretório de usuários**

- Indicadores: total, ativos, aguardando liberação, bloqueados, quantos entram por
  Microsoft, quantos ainda usam senha, ativos sem acesso há 30 dias, total no Entra ID
- Filtros por texto, perfil, situação, grupo e setor; exportação em CSV
- Alteração de perfil e situação direto na linha (com botão **Salvar** por usuário)
- **Detalhes** abre o painel completo: nome, cargo, matrícula, setor, telefone,
  e-mail do gestor, situação com motivo, perfil e grupos

Situações possíveis: `ativo`, `aguardando liberação`, `bloqueado`, `afastado`,
`desligado`. Apenas `ativo` permite entrar — as demais derrubam a sessão na entrada.
Os campos legados `active` / `is_active` continuam sincronizados por trigger, então
telas antigas seguem funcionando.

**Grupos e funções** — grupos por função (técnico, eletricista, mecânico, soldador,
supervisor, gestor…) e por setor. São a base das trilhas de treinamento obrigatório.

**Exceções de login** — quem pode entrar com e-mail e senha em vez da conta Microsoft:
terceiros, contas de serviço, colaborador sem conta Microsoft ativa. Cada exceção
aceita motivo e data de validade.

**Política de acesso** — modo do login por senha (`desativado`, `somente exceções`,
`liberado`), perfil padrão do novo colaborador, provisionamento automático, tenant.
Requer permissão `roles.manage` (super administrador).

**Auditoria** — registro imutável de provisionamentos, mudanças de perfil, bloqueios,
sessões recusadas e alterações de política.

---

## 7. Migração sem travar ninguém

A configuração escolhida é **somente Microsoft, com exceções**:

- O botão da Microsoft é o caminho principal e o formulário de senha fica escondido.
- Quem precisa de senha digita o e-mail e clica em *Entrar com e-mail e senha
  (exceção autorizada)*. O banco responde se aquele e-mail tem exceção; só então o
  campo de senha aparece.
- A migração **cadastrou automaticamente como exceção** todas as contas de senha que
  já usavam o sistema (com login registrado ou perfil diferente de `viewer`). Ninguém
  perde acesso no dia da virada.
- Conforme cada pessoa passar a entrar pela Microsoft, remova a exceção em
  **Exceções de login**.
- Quando a lista estiver vazia, desligue a senha de vez:

```sql
select public.admin_update_access_settings('{"password_login_mode":"disabled"}'::jsonb);
```

> Rode `select count(*) from public.corporate_access_allowlist where enabled;` antes de
> desligar. Contas de serviço e integrações que dependem de senha precisam ficar como
> exceção permanente.

---

## 8. Sincronização com o Entra ID

`POST /api/admin/entra/sync` (exige `users.manage`) — é o que o botão da tela chama.

O que acontece:

1. Token de aplicativo no Entra ID (client credentials).
2. Leitura paginada de `/v1.0/users` com cargo, setor, matrícula, telefones,
   `accountEnabled` e o gestor (`$expand=manager`, com fallback por usuário quando o
   tenant não permite o expand).
3. Contas fora dos domínios autorizados são descartadas — guests não entram no
   diretório.
4. Gravação em `entra_directory` e aplicação em `profiles`
   (`apply_entra_directory_to_profiles`), que também:
   - vincula `manager_id` a partir do e-mail do gestor;
   - **bloqueia no portal quem foi desativado no Entra ID**.

Cada execução fica registrada em `entra_sync_runs` com contagens e erro, se houver.

**Recomendação:** agende a sincronização diária (cron da VM, GitHub Action ou Supabase
Scheduled Function chamando o endpoint). Desligamento no RH → conta desativada no Entra
→ acesso ao portal encerrado no dia seguinte, sem ação manual.

`GET /api/admin/entra/status` devolve se a integração está configurada, o tamanho do
diretório e a última execução.

---

## 9. Respostas às perguntas da TI

| Pergunta | Resposta desta implementação |
| --- | --- |
| Podemos usar login corporativo? | Sim — Entra ID via Supabase Auth, tenant único, domínio travado no banco |
| Como obter a relação colaborador → gestor? | Microsoft Graph `manager`, gravado em `profiles.manager_id` e exposto por `get_my_team()` |
| Quem pode publicar/aprovar? | Perfis e permissões existentes (`users.manage`, `roles.manage`, `trainings.manage`) |
| Onde ficam as evidências? | Banco corporativo; toda alteração de acesso em `access_audit_log` |
| Qual serviço envia os e-mails? | Microsoft Graph `Mail.Send` com a conta de serviço (`GRAPH_SENDER_EMAIL`) |
| Qual banco? | PostgreSQL do Supabase, com RLS por perfil |
| Contas de desligados? | Bloqueio automático na sincronização; sessão derrubada na entrada seguinte |

Ainda dependem de decisão da TI (fora do escopo deste módulo): armazenamento de vídeos
e certificados, limite de tamanho de vídeo, liberação do YouTube e integração com o
catálogo corporativo de aprendizagem.

---

## 10. Verificação pós-implantação

| Teste | Resultado esperado |
| --- | --- |
| Login Microsoft com conta `@biotrop.com.br` | Entra e o perfil aparece no diretório |
| Login Microsoft com conta de outro tenant | Recusado pela Microsoft (app single tenant) |
| Conta guest do tenant com e-mail externo | Recusada pelo banco, com mensagem de domínio |
| Senha com e-mail sem exceção | Campo de senha não aparece |
| Senha com e-mail com exceção | Campo aparece e o login funciona |
| Usuário marcado como `bloqueado` | Sessão derrubada na entrada, com aviso |
| Desativar a conta no Entra e sincronizar | Situação muda para `bloqueado` automaticamente |
| Alterar perfil de alguém | Registro aparece na aba **Auditoria** |
| Tentar bloquear a própria conta | Recusado pelo banco |

---

## 11. Limites conhecidos

- **`guard_corporate_session()` roda na entrada**, não a cada requisição. Um bloqueio
  feito no meio da sessão vale no próximo carregamento (o RLS por permissão continua
  valendo imediatamente, porque `has_permission()` exige perfil ativo).
- **Sem SCIM**: o provisionamento é no primeiro login mais a sincronização agendada.
  Colaborador novo só aparece no diretório após o primeiro acesso ou após a sincronização.
- **Grupos do Entra não são importados** ainda. A coluna `access_groups.entra_group_id`
  já existe para essa evolução; hoje a atribuição de grupo é feita na tela.
- **O secret do App Registration expira.** Coloque a renovação no calendário da TI:
  quando ele vencer, o login Microsoft para de funcionar.
